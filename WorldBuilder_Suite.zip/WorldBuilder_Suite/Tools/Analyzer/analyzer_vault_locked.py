"""
Analyzer v3.0 — Vault Locked, QTL Enforced, Fully Validated
"""

from Configurations.qtl_enforcer import qtl_check
from Configurations.pathrouter import build_path
from Configurations.json_reader import load_json
from Configurations.report_writer import write_text, write_json
from Configurations.anomaly_scanner import detect_duplicates, find_orphans, validate_linkage
from Configurations.spidertree_reader import read_spidertree
from Configurations.vault_logger import VaultLogger
from datetime import datetime

class Analyzer:
    def __init__(self):
        self.tool_name = "Analyzer"
        self.input_dir = build_path(["Output", "GodTree", "Latest"])
        self.output_dir = build_path(["Output", self.tool_name])
        self.backup_dir = build_path([self.output_dir, "Backup"])
        self.timestamp = datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        self.session_dir = build_path([self.backup_dir, self.timestamp])
        self.latest_dir = build_path([self.output_dir, "Latest"])
        self.log_dir = build_path(["Logs", self.tool_name])
        self.logger = VaultLogger(self.log_dir)

        self.flatlist = []
        self.entity_map = {}
        self.syntax_map = {}
        self.import_graph = {}
        self.spidertree = []

        self.duplicate_files = []
        self.orphan_files = []
        self.inconsistencies = []
        self.anomalies = []

    def load_inputs(self):
        self.flatlist = load_json(self.input_dir, "flatlist.json")
        self.entity_map = load_json(self.input_dir, "entity_map.json")
        self.syntax_map = load_json(self.input_dir, "syntax_map.json")
        self.import_graph = load_json(self.input_dir, "import_graph.json")
        self.spidertree = read_spidertree(self.input_dir, "SpiderTree.txt")
        self.logger.log("Analyzer inputs loaded")

    def analyze(self):
        self.duplicate_files = detect_duplicates(self.flatlist)
        self.orphan_files = find_orphans(self.flatlist, self.import_graph)
        self.inconsistencies = validate_linkage(self.import_graph, self.spidertree)
        self.anomalies = self.duplicate_files + self.orphan_files + self.inconsistencies
        self.logger.log("Analyzer completed structure scan")

    def write_outputs(self):
        write_json(self.session_dir, "analyzer_report.json", {
            "duplicates": self.duplicate_files,
            "orphans": self.orphan_files,
            "inconsistencies": self.inconsistencies
        })
        write_text(self.session_dir, "diagnostic_report.txt", self._diagnostic_text())
        write_text(self.session_dir, "anomaly_report.txt", self._anomaly_text())
        write_json(self.session_dir, "log.json", self.logger.get_log())

        write_json(self.latest_dir, "analyzer_report.json", {
            "duplicates": self.duplicate_files,
            "orphans": self.orphan_files,
            "inconsistencies": self.inconsistencies
        })
        write_text(self.latest_dir, "diagnostic_report.txt", self._diagnostic_text())
        write_text(self.latest_dir, "anomaly_report.txt", self._anomaly_text())

        write_json(self.log_dir, "log.json", self.logger.get_log())

    def _diagnostic_text(self):
        return f"Analyzer Diagnostic Report\nFiles Analyzed: {len(self.flatlist)}\nTotal Anomalies: {len(self.anomalies)}"

    def _anomaly_text(self):
        lines = ["== Anomaly Report =="]
        if self.duplicate_files:
            lines.append("[Duplicates]")
            lines.extend(f" - {f}" for f in self.duplicate_files)
        if self.orphan_files:
            lines.append("[Orphans]")
            lines.extend(f" - {f}" for f in self.orphan_files)
        if self.inconsistencies:
            lines.append("[Linkage Inconsistencies]")
            lines.extend(f" - {f}" for f in self.inconsistencies)
        return "\n".join(lines)

    def run(self):
        qtl_check()
        self.logger.log("Starting Analyzer")
        self.load_inputs()
        self.analyze()
        self.write_outputs()
        self.logger.log("Analyzer completed")

if __name__ == "__main__":
    tool = Analyzer()
    tool.run()
