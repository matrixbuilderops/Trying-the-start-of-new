
"""
Fixer Tool - QTL Validated, Dual CLI Version
Full interactive menu and flag-based access for system repair, backup, AI wiring, and diagnostic operations.
"""

from configurations.qtl_enforcer import enforce_qtl
from configurations.fixer_engine import run_fix_operations
from configurations.backup_handler import create_backup, restore_backup
from configurations.analysis_diff import run_comparative_analysis
from configurations.ai_wiring import detect_ai_models, wire_ai_models
from configurations.logging_util import log_action
from configurations.menu_cli import FixerCLI
import argparse
import sys

def interactive_menu():
    while True:
        print("""
Fixer Menu:
1. Run Everything
2. Run Diagnostic Only
3. Create Backup
4. Restore Backup
5. Delete Quarantined Files
6. Delete Unused Files
7. Detect AI Models
8. Wire AI Models
9. Enable Verbose Mode
10. Enable Dry Run Mode
11. Exit
""")
        choice = input("Select an option: ")
        if choice == "1":
            run_everything()
        elif choice == "2":
            run_comparative_analysis()
        elif choice == "3":
            create_backup()
        elif choice == "4":
            point = input("Enter restore point ID: ")
            confirm = input(f"Are you sure you want to restore {point}? (y/n): ")
            if confirm.lower() == "y":
                restore_backup(point)
        elif choice == "5":
            confirm = input("Are you sure you want to delete quarantined files? (y/n): ")
            if confirm.lower() == "y":
                log_action("Deleted quarantined files")
        elif choice == "6":
            confirm = input("Are you sure you want to delete unused files? (y/n): ")
            if confirm.lower() == "y":
                log_action("Deleted unused files")
        elif choice == "7":
            detect_ai_models()
        elif choice == "8":
            wire_ai_models()
        elif choice == "9":
            log_action("Verbose mode enabled")
        elif choice == "10":
            log_action("Dry run mode activated")
        elif choice == "11":
            break
        else:
            print("Invalid option. Try again.")

@enforce_qtl
def run_everything():
    log_action("Run Everything initiated")
    create_backup()
    run_comparative_analysis()
    run_fix_operations()
    detect_ai_models()
    wire_ai_models()

@enforce_qtl
def main():
    parser = argparse.ArgumentParser(description="Fixer Tool - Flag Interface")
    parser.add_argument("--run-all", action="store_true")
    parser.add_argument("--diagnostic", action="store_true")
    parser.add_argument("--backup", action="store_true")
    parser.add_argument("--restore", type=str)
    parser.add_argument("--detect-ai", action="store_true")
    parser.add_argument("--wire-ai", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    if len(sys.argv) > 1:
        if args.run_all:
            run_everything()
        elif args.diagnostic:
            run_comparative_analysis()
        elif args.backup:
            create_backup()
        elif args.restore:
            restore_backup(args.restore)
        elif args.detect_ai:
            detect_ai_models()
        elif args.wire_ai:
            wire_ai_models()
        elif args.verbose:
            log_action("Verbose mode enabled")
        elif args.dry_run:
            log_action("Dry run mode activated")
        else:
            print("No valid flags provided.")
    else:
        interactive_menu()

if __name__ == "__main__":
    main()
