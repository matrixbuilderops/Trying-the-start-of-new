"""
GodTree v3.0 — Vault Locked, QTL Enforced, Fully Validated
"""

from Configurations.qtl_enforcer import qtl_check
from Configurations.pathrouter import build_path
from Configurations.fs_walker import get_vault_files
from Configurations.json_writer import write_json
from Configurations.vault_logger import VaultLogger
from Configurations.constraint_solver import enforce_constraints
from Configurations.syntax_mapper import extract_syntax_map
from Configurations.import_tracer import extract_imports
from Configurations.report_writer import write_text

from datetime import datetime

class GodTree:
    def __init__(self):
        self.tool_name = "GodTree"
        self.root_path = build_path(["..", "..", "vault"])
        self.output_dir = build_path(["Output", self.tool_name])
        self.backup_dir = build_path([self.output_dir, "Backup"])
        self.timestamp = datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        self.session_dir = build_path([self.backup_dir, self.timestamp])
        self.latest_dir = build_path([self.output_dir, "Latest"])
        self.log_dir = build_path(["Logs", self.tool_name])

        self.logger = VaultLogger(self.log_dir)
        self.tree = {}
        self.flatlist = []
        self.entity_map = {}
        self.syntax_map = {}
        self.import_graph = {}
        self.warnings = []

    def build_tree(self):
        enforce_constraints(self.root_path)
        files = get_vault_files(self.root_path)

        for rel_path, full_path in files:
            segments = rel_path.split("/")
            current = self.tree
            for segment in segments[:-1]:
                current = current.setdefault(segment, {})
            current[segments[-1]] = "FILE"
            self.flatlist.append(rel_path)
            self.entity_map[rel_path] = full_path

        self.syntax_map = extract_syntax_map(self.entity_map)
        self.import_graph = extract_imports(self.entity_map)
        self.logger.log("GodTree structure, syntax, and import map built")

    def write_outputs(self):
        write_json(self.session_dir, "tree.json", self.tree)
        write_json(self.session_dir, "flatlist.json", self.flatlist)
        write_json(self.session_dir, "entity_map.json", self.entity_map)
        write_json(self.session_dir, "syntax_map.json", self.syntax_map)
        write_json(self.session_dir, "import_graph.json", self.import_graph)
        write_json(self.session_dir, "warnings.json", self.warnings)

        write_text(self.session_dir, "SpiderTree.txt", self._generate_spidertree())
        write_text(self.session_dir, "diagnostic_report.txt", self._generate_diagnostic())

        write_json(self.log_dir, "log.json", self.logger.get_log())
        write_json(self.session_dir, "log.json", self.logger.get_log())

        write_json(self.latest_dir, "tree.json", self.tree)
        write_json(self.latest_dir, "flatlist.json", self.flatlist)
        write_json(self.latest_dir, "entity_map.json", self.entity_map)
        write_json(self.latest_dir, "syntax_map.json", self.syntax_map)
        write_json(self.latest_dir, "import_graph.json", self.import_graph)
        write_text(self.latest_dir, "SpiderTree.txt", self._generate_spidertree())
        write_text(self.latest_dir, "diagnostic_report.txt", self._generate_diagnostic())

    def _generate_spidertree(self):
        lines = ["== SpiderTree =="]
        for file, syntax in self.syntax_map.items():
            lines.append(f"[{file}]")
            lines.append("  - Imports:")
            for imp in self.import_graph.get(file, []):
                lines.append(f"    * {imp}")
            lines.append("  - Syntax:")
            for s in syntax:
                lines.append(f"    * {s}")
            lines.append("")
        return "\n".join(lines)

    def _generate_diagnostic(self):
        diagnostics = [f"Files Parsed: {len(self.flatlist)}"]
        diagnostics.append(f"Warnings: {len(self.warnings)}")
        return "\n".join(diagnostics)

    def run(self):
        qtl_check()
        self.logger.log("Starting GodTree")
        self.build_tree()
        self.write_outputs()
        self.logger.log("GodTree completed")

if __name__ == "__main__":
    tool = GodTree()
    tool.run()
