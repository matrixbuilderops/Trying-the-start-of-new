
"""
Ascension Base Mode - Dual CLI
"""
from configurations.qtl_enforcer import enforce_qtl
from configurations.ascension_engine import execute_ascension_base
from configurations.menu_cli import AscensionCLI
from configurations.logging_util import log_action
import argparse

@enforce_qtl
def main():
    parser = argparse.ArgumentParser(description="Ascension Base Mode CLI")
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--diagnostic", action="store_true")
    parser.add_argument("--verbose-tool", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--rerun-godtree", action="store_true")
    parser.add_argument("--rerun-analyzer", action="store_true")
    args = parser.parse_args()

    if args.run:
        execute_ascension_base()
    elif args.diagnostic:
        log_action("Diagnostic triggered")
    elif args.verbose_tool:
        log_action("Tool Verbose Mode ON")
    elif args.dry_run:
        log_action("Dry Run Mode Enabled")
    elif args.rerun_godtree:
        log_action("Re-running GodTree")
    elif args.rerun_analyzer:
        log_action("Re-running Analyzer")
    else:
        cli = AscensionCLI(llm_mode=False)
        cli.display_menu()

if __name__ == "__main__":
    main()
