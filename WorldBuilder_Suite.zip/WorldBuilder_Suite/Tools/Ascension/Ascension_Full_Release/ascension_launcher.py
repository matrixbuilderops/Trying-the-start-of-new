
"""
Ascension Launcher - Full Mode Selection
"""
import subprocess

def display_launcher():
    print("Ascension Launcher - Select Mode")
    print("1. Base Mode (Non-LLM)")
    print("2. LLM Mode (Manual)")
    print("3. LLM Mode (Auto)")
    print("4. Exit")

    choice = input("Enter choice: ")
    if choice == '1':
        subprocess.run(["python", "ascension_base.py"])
    elif choice == '2':
        subprocess.run(["python", "ascension_llm.py"])
    elif choice == '3':
        subprocess.run(["python", "ascension_llm.py", "--auto"])
    elif choice == '4':
        print("Exiting Ascension.")
    else:
        print("Invalid choice. Exiting.")

if __name__ == "__main__":
    display_launcher()
