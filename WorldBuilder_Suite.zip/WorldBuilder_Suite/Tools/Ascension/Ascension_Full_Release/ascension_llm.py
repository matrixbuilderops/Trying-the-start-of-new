
"""
Ascension LLM Mode - Auto/Manual
"""
from configurations.qtl_enforcer import enforce_qtl
from configurations.ascension_engine import execute_ascension_llm, bootstrap_ai_system
from configurations.menu_cli import AscensionCLI
from configurations.ai_detection import detect_llm_capability
from configurations.helix_pass import helix_validate_and_refine
import argparse

@enforce_qtl
def auto_mode():
    if not detect_llm_capability():
        print("LLM not detected. You may install or purchase the LLM-Enhanced Tool.")
        return
    print("Auto LLM Execution Mode Enabled.")
    result = execute_ascension_llm()
    helix_validate_and_refine(result)

@enforce_qtl
def main():
    parser = argparse.ArgumentParser(description="Ascension LLM CLI")
    parser.add_argument("--auto", action="store_true")
    parser.add_argument("--verbose-llm", action="store_true")
    parser.add_argument("--bootstrap", action="store_true")
    args = parser.parse_args()

    if args.auto:
        auto_mode()
    elif args.bootstrap:
        bootstrap_ai_system()
    elif args.verbose_llm:
        print("LLM Verbose Mode ON")
    else:
        if not detect_llm_capability():
            print("LLM not detected. You may install or purchase the LLM-Enhanced Tool.")
            return
        cli = AscensionCLI(llm_mode=True)
        cli.display_menu()

if __name__ == "__main__":
    main()
