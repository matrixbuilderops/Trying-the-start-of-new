"""
worldbuilder.fs_walker
Performs recursive directory walking and file mapping.
"""
from pathlib import Path

def walk_fs(root: str) -> list:
    return [str(path) for path in Path(root).rglob("*") if path.is_file()]
