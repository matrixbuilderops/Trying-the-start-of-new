"""
configurations.validator_hooks
Attaches pre-execution validation routines.
"""
def validate_before_run(flags: dict) -> bool:
    return flags.get("safe_mode", False)
