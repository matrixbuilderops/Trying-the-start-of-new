"""
worldbuilder.report_writer
Generates and outputs structured report data.
"""
from typing import Dict

def write_report(data: Dict[str, str], path: str) -> None:
    with open(path, 'w') as file:
        for key, value in data.items():
            file.write(f"{key}: {value}\n")
