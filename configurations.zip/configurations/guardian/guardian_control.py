"""
configurations.guardian.guardian_control
Controls state of Guardian services and internal checks.
"""
def toggle_guardian_state(active: bool) -> str:
    return "Guardian Activated" if active else "Guardian Dormant"
