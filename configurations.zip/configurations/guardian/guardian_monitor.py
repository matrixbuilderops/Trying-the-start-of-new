"""
configurations.guardian.guardian_monitor
Monitors file access and behavioral anomalies.
"""
import os
from typing import List

def monitor_access(paths: List[str]) -> List[str]:
    return [p for p in paths if os.path.exists(p)]
