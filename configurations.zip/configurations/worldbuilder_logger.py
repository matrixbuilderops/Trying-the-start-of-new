"""
worldbuilder_logger.py — Logging for WorldBuilderSuite, tool-safe, buffered.
"""

class VaultLogger:
    def __init__(self, log_dir: str):
        self.log_dir = log_dir
        self.entries = []

    def log(self, message: str):
        self.entries.append(message)

    def get_log(self):
        return self.entries

