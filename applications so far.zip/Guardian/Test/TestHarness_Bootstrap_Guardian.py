# File: TestHarness_Bootstrap_Guardian.py
# Location: /Helix/Configuration/Applications/Guardian/Test/
# Description: Launches test validation for all Guardian module hooks.

from LogicSolver import HarnessValidator
from Hooks import HelixBridge

def test_all_guardian_hooks():
    modules = HelixBridge.scan_for("guardian.module")
    return HarnessValidator.run_all(modules)

if __name__ == "__main__":
    results = test_all_guardian_hooks()
    for r in results:
        print(f"Test: {r['module']} | Result: {r['status']}")

