# File: SystemInterface_Relay.py
# Location: /Helix/Configuration/Applications/Guardian/InterfaceBridge/
# Description: Routes Guardian system events between Helix backend and OS runtime.

from LogicSolver import SignalInterpret
from QTL import QTL_Hook
from Hooks import SystemBus, EventFlag

@QTL_Hook("guardian.interfacebridge.osrelay_v1")
def route_guardian_events(event_packet):
    if SignalInterpret.is_valid(event_packet):
        EventFlag.log("GuardianEvent", event_packet)
        SystemBus.dispatch(event_packet)
        return {"status": "event routed", "payload": event_packet}
    return {"status": "invalid event", "error": True}

def guardian_event_loop():
    while True:
        packet = SystemBus.receive("guardian")
        if packet:
            route_guardian_events(packet)

# Note: Event loop only active in runtime binding, not during test harness

