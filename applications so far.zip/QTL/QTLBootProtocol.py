# QTLBootProtocol.py
# Cleanroom — Dormant/Active Trigger Logic
# Unique ID: QTL-BOOT-004

from logic_solver import verify_identity

DORMANT_DEVICES = set()
ACTIVE_DEVICES = set()

def register_dormant_device(device_id):
    if verify_identity(device_id):
        DORMANT_DEVICES.add(device_id)

def awaken_device(device_id):
    if device_id in DORMANT_DEVICES:
        DORMANT_DEVICES.remove(device_id)
        ACTIVE_DEVICES.add(device_id)
        return True
    return False

def is_active(device_id):
    return device_id in ACTIVE_DEVICES

