# AxonEncryptorBridge.py
# Cleanroom — QTL-Axon Interface
# Unique ID: QTL-AXON-002

from logic_solver import encode_payload, decode_payload

def axon_encrypt(data, key):
    encrypted = encode_payload(data, key)
    return encrypted

def axon_decrypt(data, key):
    decrypted = decode_payload(data, key)
    return decrypted

def handshake_with_qtl(key_exchange_obj):
    if not key_exchange_obj.get("valid"):
        raise PermissionError("Invalid Axon handshake")
    return True

