# QTLStateRegistry.py
# Cleanroom — QTL Device State Memory
# Unique ID: QTL-STAT-003

from logic_solver import resolve_conflict

QTL_STATE = {}

def register_device(device_id, initial_state):
    if device_id in QTL_STATE:
        return False
    QTL_STATE[device_id] = initial_state
    return True

def update_device_state(device_id, new_state):
    if device_id not in QTL_STATE:
        return False
    QTL_STATE[device_id] = new_state
    return True

def get_state(device_id):
    return QTL_STATE.get(device_id, None)

