import os
import re

# === RecursiveHookRealigner ===
# Normalizes hook syntax, reorganizes placement, and ensures recursive traceability across file layers.

VALID_HOOK_TAGS = [
    "QTLHook", "TestHarnessHook", "UpgradeSyncHook", "ValidatorTraceHook", "AxonFlowHook"
]

HOOK_PATTERN = re.compile(r'#\s*HOOK\s*:\s*(\w+)', re.IGNORECASE)

def normalize_hook_line(hook_line):
    match = HOOK_PATTERN.match(hook_line.strip())
    if match:
        tag = match.group(1)
        normalized = tag[0].upper() + tag[1:]
        if normalized not in VALID_HOOK_TAGS:
            normalized = "QTLHook"
        return f"# HOOK: {normalized}\n"
    return hook_line

def realign_hooks(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()

    new_lines = []
    for line in lines:
        if "HOOK" in line:
            new_lines.append(normalize_hook_line(line))
        else:
            new_lines.append(line)

    with open(file_path, 'w') as f:
        f.writelines(new_lines)

    print(f"HOOKS REALIGNED: {file_path}")

def process_all_qtl_files(root_dir):
    for dirpath, _, filenames in os.walk(root_dir):
        for filename in filenames:
            if filename.endswith(".qtl"):
                realign_hooks(os.path.join(dirpath, filename))

if __name__ == "__main__":
    base_path = "./Toolset"  # Update if your directory is different
    process_all_qtl_files(base_path)

