# CommandFlagIntegrityChecker.py

"""
CommandFlagIntegrityChecker
---------------------------
Scans each front-facing tool in the system to verify that:
1. Every command in the interactive interface has a corresponding flag.
2. Every flag links to valid internal logic.
3. There are no orphan flags (defined but unused).
4. There are no conflicting aliases.
"""

import os
import re

def extract_flags(file_content):
    return re.findall(r"--([a-zA-Z0-9_]+)", file_content)

def extract_interface_commands(file_content):
    return re.findall(r"\[\d+\]\s+([a-zA-Z0-9 _-]+)", file_content)

def validate_flags(commands, flags):
    results = {
        "missing_flags": [],
        "unused_flags": [],
        "conflicts": []
    }

    command_aliases = set(c.lower().replace(" ", "_") for c in commands)
    flag_set = set(flags)

    # 1. Check for commands that are missing flags
    for cmd in command_aliases:
        if cmd not in flag_set:
            results["missing_flags"].append(cmd)

    # 2. Check for flags that aren't tied to a command
    for flag in flag_set:
        if flag not in command_aliases:
            results["unused_flags"].append(flag)

    # 3. Detect conflicts: duplicate flag names or synonyms
    if len(flag_set) != len(flags):
        results["conflicts"].append("Duplicate or conflicting flag names detected.")

    return results

def scan_directory(root_dir):
    report = {}
    for dirpath, _, filenames in os.walk(root_dir):
        for fname in filenames:
            if fname.endswith(".qtl"):
                full_path = os.path.join(dirpath, fname)
                with open(full_path, "r") as f:
                    content = f.read()
                flags = extract_flags(content)
                commands = extract_interface_commands(content)
                result = validate_flags(commands, flags)
                if any(result.values()):
                    report[fname] = result
    return report

if __name__ == "__main__":
    from pprint import pprint
    scan_path = "./Applications"
    integrity_report = scan_directory(scan_path)
    print("\n\nCommand Flag Integrity Report")
    print("=" * 40)
    pprint(integrity_report)

