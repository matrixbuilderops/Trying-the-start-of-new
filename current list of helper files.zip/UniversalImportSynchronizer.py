import os
import re

# === UniversalImportSynchronizer ===
# Aligns all import statements across files to conform to a consistent standard.
# Applies proper hierarchy rules, syntax consistency, and module dependency mapping.

IMPORT_PATTERN = re.compile(r'^(use|import)\s+([A-Za-z0-9_./]+)', re.IGNORECASE)
VALID_IMPORTS = ["HelixBackend", "Validator", "Vault", "Axon", "PatchLine", "Guardian", "RAMRelocator", "QTL", "Ascenda", "Core"]

def normalize_import(import_line):
    match = IMPORT_PATTERN.match(import_line.strip())
    if not match:
        return import_line

    directive, module = match.groups()
    module_parts = module.replace("\\", "/").split('/')
    module_clean = module_parts[-1].replace(".qtl", "").strip()

    if module_clean not in VALID_IMPORTS:
        return f"use Core\n"
    else:
        return f"use {module_clean}\n"

def sync_imports_in_file(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()

    new_lines = []
    for line in lines:
        if IMPORT_PATTERN.match(line):
            new_lines.append(normalize_import(line))
        else:
            new_lines.append(line)

    with open(file_path, 'w') as f:
        f.writelines(new_lines)

    print(f"IMPORTS SYNCHRONIZED: {file_path}")

def process_all_qtl_files(root_dir):
    for dirpath, _, filenames in os.walk(root_dir):
        for filename in filenames:
            if filename.endswith(".qtl"):
                sync_imports_in_file(os.path.join(dirpath, filename))

if __name__ == "__main__":
    base_path = "./Toolset"  # Set this to the base directory of your toolset
    process_all_qtl_files(base_path)

