#META-BEGIN
{
  "Tool": "WorldBuilder_CleanOrchestration_FIXED.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-e52e9c9c7c602f6d",
  "LastUpdated": "2025-06-23T01:54:14.312756",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
#!/usr/bin/env python3

import subprocess
import os

# Set the base path to the WorldBuilder directory
BASE_PATH = os.path.join(os.path.dirname(__file__), "WorldBuilder")

# Ordered list of baby scripts based on actual function
SCRIPT_SEQUENCE = [
    "ImportNormalizer.py",
    "Universal Import Synchronizer.py",
    "Recursive Hook Realigner.py",
    "HookNormalizer.py",
    "HookNormalizer2.py",
    "File Role Verifier.py",
    "CommandInterfaceRegenerator.py",
    "TestHarnessBinder.py",
    "Command Flag Integrity Checker.py",
    "QTL Consistency Auditor.py",
    "QTLIdentifiers.py",
    "Metadata Refinery.py",
    "UpgradeApplier.py",
    "Condenser.py",
    "Upgrade Listener.py",
    "Health Monitor Script.py"
]

def run_script(script_name):
    script_path = os.path.join(BASE_PATH, script_name)
    if not os.path.exists(script_path):
        print(f"[!] Skipped: {script_name} (not found at {script_path})")
        return
    try:
        print(f"▶ Running: {script_name}")
        subprocess.run(["python3", script_path], check=True)
        print(f"✓ Done: {script_name}\n")
    except subprocess.CalledProcessError as e:
        print(f"[✗] Error in {script_name}: {e}\n")

def main():
    print("🔧 Starting WorldBuilder Orchestration (Fixed Path Version)...")
    for script in SCRIPT_SEQUENCE:
        run_script(script)
    print("✅ WorldBuilder repair pass complete.")

if __name__ == "__main__":
    main()
