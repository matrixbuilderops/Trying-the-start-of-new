#META-BEGIN
{
  "Tool": "Recursive Hook Realigner.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-58496737da1b522a",
  "LastUpdated": "2025-06-23T01:54:14.312276",
  "Hook": "Hook:TestHarness",
  "ChainLink": True,
  "Encrypted": False,
  "SelfContained": True
}
#META-END
# QTL_ID: QTLHookRealigner_006
# Name: Recursive Hook Realigner
# Purpose: Ensures all QTL hooks point to valid and active reference files across recursion layers
# Hook: QTLHook::HookRealign
# Harness: TestHarness::HookValidator

def realign_hooks(directory):
    import os
    hook_reference = "QTLHook"

    for fname in os.listdir(directory):
        if fname.endswith('.py'):
            with open(os.path.join(directory, fname), 'r') as file:
                content = file.read()
            if hook_reference not in content:
                print(f"{fname} -> ⚠️ Missing QTLHook")

