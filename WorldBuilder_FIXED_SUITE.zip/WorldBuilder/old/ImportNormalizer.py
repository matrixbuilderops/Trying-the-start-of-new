#META-BEGIN
{
  "Tool": "ImportNormalizer.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-7725d46fdc075d3a",
  "LastUpdated": "2025-06-23T01:54:14.315398",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
import os
import re

def normalize_imports_in_qtl_file(file_path):
    with open(file_path, 'r') as f:
        content = f.read()

    # Normalize import lines
    content = re.sub(r'(import|use)\s+["\']?([\w./\\]+)["\']?', lambda m: normalize_import_line(m.group(2)), content)

    # Normalize hook references (e.g., Hook QTL -> QTLHook)
    content = re.sub(r'\b(Hook|hook)\s+(\w+)', lambda m: f"{m.group(2)}Hook", content)

    with open(file_path, 'w') as f:
        f.write(content)

def normalize_import_line(import_string):
    import_string = import_string.replace("\\", "/")
    parts = import_string.strip().split("/")
    folder_name = parts[0]
    return f"use {folder_name}"

def normalize_all_qtl_files(root_dir):
    for subdir, _, files in os.walk(root_dir):
        for filename in files:
            if filename.endswith(".qtl"):
                full_path = os.path.join(subdir, filename)
                normalize_imports_in_qtl_file(full_path)

if __name__ == "__main__":
    ROOT_DIRECTORY = "./"  # Replace with root path of your QTL system
    normalize_all_qtl_files(ROOT_DIRECTORY)

