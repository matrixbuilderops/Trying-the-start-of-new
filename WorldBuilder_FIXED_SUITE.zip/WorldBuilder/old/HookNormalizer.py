#META-BEGIN
{
  "Tool": "HookNormalizer.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-d2e994e49247ed06",
  "LastUpdated": "2025-06-23T01:54:14.315479",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
import os
import re

STANDARD_HOOKS = [
    "QTLHook",
    "TestHarnessHook"
]

def remove_existing_hooks(lines):
    cleaned = []
    for line in lines:
        if not line.strip().startswith("#HOOK:"):
            cleaned.append(line)
    return cleaned

def insert_standard_hooks(lines):
    hook_lines = [f"#HOOK: {hook}" for hook in STANDARD_HOOKS]
    insertion_index = 0
    # Optionally insert after metadata if it exists
    for i, line in enumerate(lines):
        if line.strip().startswith("#META: End"):
            insertion_index = i + 1
            break
    return lines[:insertion_index] + [""] + hook_lines + [""] + lines[insertion_index:]

def update_hooks_in_file(file_path):
    with open(file_path, 'r') as f:
        lines = f.read().splitlines()
    
    lines = remove_existing_hooks(lines)
    lines = insert_standard_hooks(lines)
    
    with open(file_path, 'w') as f:
        f.write("\n".join(lines))

def normalize_hooks_in_directory(root_dir):
    for subdir, _, files in os.walk(root_dir):
        for filename in files:
            if filename.endswith(".qtl"):
                file_path = os.path.join(subdir, filename)
                update_hooks_in_file(file_path)

if __name__ == "__main__":
    ROOT_DIRECTORY = "./"  # Adjust as needed
    normalize_hooks_in_directory(ROOT_DIRECTORY)

