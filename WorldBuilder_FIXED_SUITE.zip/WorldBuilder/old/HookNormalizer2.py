#META-BEGIN
{
  "Tool": "HookNormalizer2.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-5a4c1fb2256e66d6",
  "LastUpdated": "2025-06-23T01:54:14.315746",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# HookNormalizer.py
# Standardizes hook declarations across QTL files

import os
import re

ROOT_DIRECTORY = "."  # Set this to your QTL root directory
STANDARD_HOOK_FORMAT = r"Hook: \./(hooks|configs)/[a-zA-Z0-9_/]+\.qtl"

def normalize_hooks(content: str) -> str:
    lines = content.splitlines()
    new_lines = []
    hooks = []

    for line in lines:
        if line.strip().startswith("Hook:"):
            match = re.match(r"Hook:\s*(.*)", line.strip())
            if match:
                hook_path = match.group(1).strip()
                hook_path = re.sub(r"[\"']", "", hook_path)
                hook_path = hook_path.replace("\\", "/")
                if not hook_path.startswith("./"):
                    hook_path = "./" + hook_path
                hooks.append(f"Hook: {hook_path}")
        else:
            new_lines.append(line)

    # Eliminate duplicates, preserve order
    hooks = sorted(set(hooks))

    # Inject hooks after last metadata or import line
    insert_index = 0
    for i, line in enumerate(new_lines):
        if line.strip().startswith("Use:") or line.strip().startswith("QTLHook") or line.strip().startswith("ChainLinkActivated") or line.strip().startswith("UUID:"):
            insert_index = i + 1

    for hook in reversed(hooks):
        new_lines.insert(insert_index, hook)

    return "\n".join(new_lines)

def normalize_all_hooks():
    for dirpath, _, filenames in os.walk(ROOT_DIRECTORY):
        for filename in filenames:
            if filename.endswith(".qtl"):
                full_path = os.path.join(dirpath, filename)
                with open(full_path, "r", encoding="utf-8") as f:
                    content = f.read()

                updated = normalize_hooks(content)
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(updated)
                print(f"Hooks normalized: {full_path}")

if __name__ == "__main__":
    normalize_all_hooks()

