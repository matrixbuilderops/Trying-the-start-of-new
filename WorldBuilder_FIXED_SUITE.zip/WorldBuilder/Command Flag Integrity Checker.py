#META-BEGIN
{
  "Tool": "Command Flag Integrity Checker.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-50336d5a171edcae",
  "LastUpdated": "2025-06-23T01:54:14.313260",
  "Hook": "Hook:TestHarness",
  "ChainLink": True,
  "Encrypted": False,
  "SelfContained": True
}
#META-END
# QTL_ID: QTLFlagCheck_004
# Name: Command Flag Integrity Checker
# Purpose: Validates that each tool’s command-line flags correspond to implemented features
# Hook: QTLHook::FlagScan
# Harness: TestHarness::CommandParserCheck

def check_flags(tool_code):
    required_flags = ["--run", "--dry-run", "--help"]
    found = [flag for flag in required_flags if flag in tool_code]
    missing = list(set(required_flags) - set(found))
    return {"found": found, "missing": missing}

