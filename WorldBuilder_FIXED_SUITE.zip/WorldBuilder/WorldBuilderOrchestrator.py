#META-BEGIN
{
  "Tool": "WorldBuilderOrchestrator.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-605914f2afc6ae71",
  "LastUpdated": "2025-06-23T01:54:14.311795",
  "Hook": "Hook:TestHarness",
  "ChainLink": True,
  "Encrypted": False,
  "SelfContained": True
}
#META-END
# WorldBuilderOrchestrator.py

import os
import subprocess

TOOLSET_NAME = "WorldBuilder"
HELPER_SCRIPTS = [
    "ImportNormalizer.py",
    "RecursiveHookRealigner.py",
    "TestHarnessBinder.py",
    "UniversalSynchronizer.py",
    "UpgradeApplier.py",
    "HookNormalizer.py",
    "QTLIntegrityChecker.py",
    "ForkMapValidator.py"
]

APPLICATION_FILES = [
    "QTLCompiler.py",
    "ValidatorCore.py",
    "VaultEmbedder.py",
    "PatchlineGenerator.py",
    "GuardianThreader.py",
    "RAMRelocator.py"
]

def run_script(path):
    print(f"[{TOOLSET_NAME}] Executing: {path}")
    subprocess.run(["python3", path])

def orchestrate():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    toolset_path = os.path.join(base_dir, TOOLSET_NAME)

    if not os.path.exists(toolset_path):
        raise Exception(f"{TOOLSET_NAME} directory not found at expected location.")

    print(f"[*] Orchestrating setup for {TOOLSET_NAME}...")

    for script in HELPER_SCRIPTS:
        script_path = os.path.join(toolset_path, script)
        if os.path.exists(script_path):
            run_script(script_path)
        else:
            print(f"[!] Missing helper script: {script}")

    print(f"[✓] WorldBuilder orchestration complete.")

if __name__ == "__main__":
    orchestrate()