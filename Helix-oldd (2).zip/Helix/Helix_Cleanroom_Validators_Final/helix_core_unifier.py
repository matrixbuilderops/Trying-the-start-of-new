"""
Unifier Orchestrator

Aggregates results from all validation modules and produces a unified report.
"""

def unify_results(modules_results):
    combined = []
    seen = set()
    for result in modules_results:
        for item in result:
            key = f"{item.get('line', '')}:{item.get('message', '')}"
            if key not in seen:
                seen.add(key)
                combined.append(item)
    return combined

if __name__ == "__main__":
    def test():
        print("Running internal test for: helix_core_unifier.py")
        # Placeholders for demonstration. Replace with actual internal validation tests.
        sample = ["example line"]
        try:
            result = validate(sample) if "validate" in globals() else (
                     scan_for_danger(sample) if "scan_for_danger" in globals() else (
                     check_format(sample) if "check_format" in globals() else (
                     align_signature({"args": [], "return": None}) if "align_signature" in globals() else (
                     audit_logic(["if", "try"]) if "audit_logic" in globals() else (
                     unify_results([[{"line": 1, "message": "test"}]]) if "unify_results" in globals() else (
                     normalize_errors(["SyntaxError: 10: invalid"]) if "normalize_errors" in globals() else (
                     resolve_type("x", 5) if "resolve_type" in globals() else (
                     validate_chain({"type": "check", "key": "pass", "expected": True}, {"pass": True}) if "validate_chain" in globals() else (
                     helix_static_info() if "helix_static_info" in globals() else "No test found"))))))))
            print("Test Output:", result)
        except Exception as e:
            print("Test failed:", e)

    test()

def _test_core_unifier():
    results = [[{"line": 1, "message": "x"}], [{"line": 1, "message": "x"}, {"line": 2, "message": "y"}]]
    unified = unify_results(results)
    assert len(unified) == 2
    print("helix_core_unifier.py test: PASSED")

if __name__ == "__main__":
    _test_core_unifier()
