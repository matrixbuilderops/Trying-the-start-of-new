"""
Import Flux Validator

Detects wildcards, duplicate imports, and unsafe relative references.
"""

def validate_imports(source_lines):
    seen = set()
    issues = []
    for i, line in enumerate(source_lines):
        if "import *" in line:
            issues.append(f"Line {i+1}: wildcard import")
        if line.strip() in seen:
            issues.append(f"Line {i+1}: duplicate import")
        seen.add(line.strip())
    return issues

if __name__ == "__main__":
    def test():
        print("Running internal test for: helix_tools_import_flux.py")
        # Placeholders for demonstration. Replace with actual internal validation tests.
        sample = ["example line"]
        try:
            result = validate(sample) if "validate" in globals() else (
                     scan_for_danger(sample) if "scan_for_danger" in globals() else (
                     check_format(sample) if "check_format" in globals() else (
                     align_signature({"args": [], "return": None}) if "align_signature" in globals() else (
                     audit_logic(["if", "try"]) if "audit_logic" in globals() else (
                     unify_results([[{"line": 1, "message": "test"}]]) if "unify_results" in globals() else (
                     normalize_errors(["SyntaxError: 10: invalid"]) if "normalize_errors" in globals() else (
                     resolve_type("x", 5) if "resolve_type" in globals() else (
                     validate_chain({"type": "check", "key": "pass", "expected": True}, {"pass": True}) if "validate_chain" in globals() else (
                     helix_static_info() if "helix_static_info" in globals() else "No test found"))))))))
            print("Test Output:", result)
        except Exception as e:
            print("Test failed:", e)

    test()

def _test_tools_import_flux():
    lines = ["import os\n", "import *\n", "import os\n"]
    result = validate_imports(lines)
    assert any("wildcard" in x for x in result)
    assert any("duplicate" in x for x in result)
    print("helix_tools_import_flux.py test: PASSED")

if __name__ == "__main__":
    _test_tools_import_flux()
