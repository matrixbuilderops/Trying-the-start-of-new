"""
Helix Core Module: helix_compile

Compiles source logic into validated callable modules for Helix.
Handles syntax enforcement and standard entrypoint formatting.
"""

from core.helix_error import ValidationError

class HelixCompiler:
    def __init__(self):
        self._compiled = {}

    def compile(self, name: str, fn):
        if not callable(fn):
            raise ValidationError(f"Logic unit '{name}' must be callable")
        self._compiled[name] = fn

    def dump(self):
        return self._compiled

# Preserved test logic
def _test_helix_compile():
    c = HelixCompiler()
    c.compile("echo", lambda x: x)
    compiled = c.dump()
    assert "echo" in compiled
    assert compiled["echo"](42) == 42
    print("HelixCompiler tests: PASSED")

if __name__ == "__main__":
    _test_helix_compile()
