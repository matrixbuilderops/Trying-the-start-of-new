"""
Helix Core Module: helix_patch

Applies validated hotfixes or rebindings to live Helix logic.
Supports logic overwrite and rollback entrypoints.
"""

from core.helix_error import ValidationError

class HelixPatch:
    def __init__(self, registry):
        self._registry = registry

    def apply(self, name: str, fn):
        if not callable(fn):
            raise ValidationError(f"Patch for '{name}' must be callable")
        self._registry[name] = fn

# Preserved test logic
def _test_helix_patch():
    reg = {"old": lambda x: x + 1}
    p = HelixPatch(reg)
    p.apply("old", lambda x: x * 2)
    assert reg["old"](3) == 6
    print("HelixPatch tests: PASSED")

if __name__ == "__main__":
    _test_helix_patch()
