"""
Helix Core Module: helix_build

Builds logic trees from compiled code, establishing runtime-ready callable graphs.
Supports execution chaining and injection context.
"""

from core.helix_error import ValidationError

class HelixBuilder:
    def __init__(self):
        self._compiled = {}

    def bind(self, compiled):
        if not isinstance(compiled, dict):
            raise ValidationError("Expected dict of compiled logic")
        self._compiled = compiled

    def execute(self, name: str, *args, **kwargs):
        if name not in self._compiled:
            raise ValidationError(f"No logic named '{name}' found")
        return self._compiled[name](*args, **kwargs)

# Preserved test logic (breaks out of context if imports aren't present)
def _test_helix_build():
    b = HelixBuilder()
    b.bind({"sum": lambda x, y: x + y})
    assert b.execute("sum", 2, 3) == 5
    print("HelixBuilder tests: PASSED")

if __name__ == "__main__":
    _test_helix_build()
