#!/bin/bash

set -e

# Delete old files and copy in cleanroom replacements

echo "Replacing: /mnt/data/helix_latest/Helix/setup.py"
rm -f "/mnt/data/helix_latest/Helix/setup.py"
cp "/mnt/data/helix_cleanroom/setup.py" "/mnt/data/helix_latest/Helix/setup.py"

echo "Replacing: /mnt/data/helix_latest/Helix/core/helix_core_validation_logic.py"
rm -f "/mnt/data/helix_latest/Helix/core/helix_core_validation_logic.py"
cp "/mnt/data/helix_cleanroom/helix_core_validation_logic.py" "/mnt/data/helix_latest/Helix/core/helix_core_validation_logic.py"

echo "Replacing: /mnt/data/helix_latest/Helix/tools/helix_tools_type_align.py"
rm -f "/mnt/data/helix_latest/Helix/tools/helix_tools_type_align.py"
cp "/mnt/data/helix_cleanroom/helix_tools_type_align.py" "/mnt/data/helix_latest/Helix/tools/helix_tools_type_align.py"

echo "Replacing: /mnt/data/helix_latest/Helix/core/helix_core_error_validate.py"
rm -f "/mnt/data/helix_latest/Helix/core/helix_core_error_validate.py"
cp "/mnt/data/helix_cleanroom/helix_core_error_validate.py" "/mnt/data/helix_latest/Helix/core/helix_core_error_validate.py"

echo "Replacing: /mnt/data/helix_latest/Helix/tools/helix_tools_type_r.py"
rm -f "/mnt/data/helix_latest/Helix/tools/helix_tools_type_r.py"
cp "/mnt/data/helix_cleanroom/helix_tools_type_r.py" "/mnt/data/helix_latest/Helix/tools/helix_tools_type_r.py"

echo "Replacing: /mnt/data/helix_latest/Helix/tools/helix_tools_format_guard.py"
rm -f "/mnt/data/helix_latest/Helix/tools/helix_tools_format_guard.py"
cp "/mnt/data/helix_cleanroom/helix_tools_format_guard.py" "/mnt/data/helix_latest/Helix/tools/helix_tools_format_guard.py"

echo "Replacing: /mnt/data/helix_latest/Helix/tools/helix_tools_import_flux.py"
rm -f "/mnt/data/helix_latest/Helix/tools/helix_tools_import_flux.py"
cp "/mnt/data/helix_cleanroom/helix_tools_import_flux.py" "/mnt/data/helix_latest/Helix/tools/helix_tools_import_flux.py"

echo "Replacing: /mnt/data/helix_latest/Helix/tools/helix_tools_secure_trace.py"
rm -f "/mnt/data/helix_latest/Helix/tools/helix_tools_secure_trace.py"
cp "/mnt/data/helix_cleanroom/helix_tools_secure_trace.py" "/mnt/data/helix_latest/Helix/tools/helix_tools_secure_trace.py"

echo "Replacing: /mnt/data/helix_latest/Helix/core/helix_core_logic_validate.py"
rm -f "/mnt/data/helix_latest/Helix/core/helix_core_logic_validate.py"
cp "/mnt/data/helix_cleanroom/helix_core_logic_validate.py" "/mnt/data/helix_latest/Helix/core/helix_core_logic_validate.py"

echo "Replacing: /mnt/data/helix_latest/Helix/core/helix_core_unifier.py"
rm -f "/mnt/data/helix_latest/Helix/core/helix_core_unifier.py"
cp "/mnt/data/helix_cleanroom/helix_core_unifier.py" "/mnt/data/helix_latest/Helix/core/helix_core_unifier.py"
