"""
Helix Tools Module: helix_scan

Performs lightweight analysis on logic nodes and detects structural metadata.
Used for validation prior to execution binding.
"""

from core.helix_error import ValidationError

class ToolScan:
    def audit(self, fn):
        if not callable(fn):
            raise ValidationError("Scan requires callable input")
        return {
            "args": fn.__code__.co_varnames[:fn.__code__.co_argcount],
            "name": fn.__name__,
            "locals": fn.__code__.co_nlocals
        }

# Preserved test logic
def _test_tools_helix_scan():
    def probe(x, y): return x + y
    meta = ToolScan().audit(probe)
    assert meta["name"] == "probe"
    assert meta["args"] == ('x', 'y')
    print("ToolScan tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_scan()
