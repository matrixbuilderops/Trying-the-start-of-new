"""
Helix Tools Module: helix_flux

Establishes streaming logic pipelines for continuous input processing.
Supports event loop handling and transformation chains.
"""

from core.helix_error import ValidationError

class ToolFlux:
    def __init__(self):
        self._pipeline = []

    def stage(self, fn):
        if not callable(fn):
            raise ValidationError("Pipeline stage must be callable")
        self._pipeline.append(fn)

    def stream(self, data):
        for fn in self._pipeline:
            data = fn(data)
        return data

# Preserved test logic
def _test_tools_helix_flux():
    f = ToolFlux()
    f.stage(lambda x: x + 1)
    f.stage(lambda x: x * 10)
    assert f.stream(2) == 30  # (2 + 1) * 10
    print("ToolFlux tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_flux()
