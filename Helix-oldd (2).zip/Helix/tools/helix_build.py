"""
Helix Tools Module: helix_build

Constructs logic execution chains across validated tool modules.
Integrates compiled-patched pairs into sequence.
"""

from core.helix_error import ValidationError

class ToolBuilder:
    def __init__(self):
        self._chain = []

    def add(self, fn):
        if not callable(fn):
            raise ValidationError("Tool module must be callable")
        self._chain.append(fn)

    def run(self, *args, **kwargs):
        out = args
        for fn in self._chain:
            if isinstance(out, tuple):
                out = fn(*out, **kwargs)
            else:
                out = fn(out, **kwargs)
        return out

# Preserved test logic
def _test_tools_helix_build():
    b = ToolBuilder()
    b.add(lambda x: x + 1)
    b.add(lambda y: y * 2)
    assert b.run(3) == 8  # (3 + 1) * 2
    print("ToolBuilder tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_build()
