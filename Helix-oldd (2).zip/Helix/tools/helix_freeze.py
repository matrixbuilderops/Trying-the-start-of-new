"""
Helix Tools Module: helix_freeze

Captures toolchain state at runtime for freeze-frame diagnostics.
Supports rollback, inspection, and debug state preservation.
"""

from core.helix_error import ValidationError

class ToolFreeze:
    def __init__(self):
        self._snapshots = {}

    def capture(self, tag: str, state):
        if not isinstance(tag, str):
            raise ValidationError("Snapshot tag must be a string")
        self._snapshots[tag] = state

    def retrieve(self, tag: str):
        if tag not in self._snapshots:
            raise ValidationError(f"No snapshot named '{tag}'")
        return self._snapshots[tag]

# Preserved test logic
def _test_tools_helix_freeze():
    f = ToolFreeze()
    f.capture("before", {"x": 42})
    assert f.retrieve("before") == {"x": 42}
    try:
        f.retrieve("ghost")
    except ValidationError:
        print("ToolFreeze tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_freeze()
