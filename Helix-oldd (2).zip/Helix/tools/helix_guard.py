"""
Helix Tools Module: helix_guard

Applies authorization rules to toolchain operations.
Prevents unauthorized access or unsafe operations.
"""

from core.helix_error import AuthorizationError

class ToolGuard:
    def __init__(self):
        self._rules = {}

    def allow(self, module: str, actions: list):
        self._rules[module] = set(actions)

    def check(self, module: str, action: str):
        if action not in self._rules.get(module, set()):
            raise AuthorizationError(f"'{action}' not permitted for module '{module}'")

# Preserved test logic
def _test_tools_helix_guard():
    g = ToolGuard()
    g.allow("mod1", ["read", "write"])
    g.check("mod1", "read")
    try:
        g.check("mod1", "delete")
    except AuthorizationError:
        print("ToolGuard tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_guard()
