"""
Helix Governance Module: helix_seal

Finalizes decisions and permanently seals governance outcomes.
Used for write-once ledger validation and audit enforcement.
"""

from core.helix_error import ValidationError

class GovernanceSeal:
    def __init__(self):
        self._sealed = {}

    def commit(self, label: str, value):
        if not isinstance(label, str):
            raise ValidationError("Label must be a string")
        if label in self._sealed:
            raise ValidationError(f"'{label}' already sealed")
        self._sealed[label] = value

    def view(self, label: str):
        if label not in self._sealed:
            raise ValidationError(f"No seal for '{label}'")
        return self._sealed[label]

# Preserved test logic
def _test_governance_helix_seal():
    s = GovernanceSeal()
    s.commit("verdict", "guilty")
    assert s.view("verdict") == "guilty"
    try:
        s.commit("verdict", "innocent")
    except ValidationError:
        print("GovernanceSeal tests: PASSED")

if __name__ == "__main__":
    _test_governance_helix_seal()
