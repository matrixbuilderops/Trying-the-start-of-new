"""
Helix Governance Module: helix_log

Records governance actions, policy decisions, and rule evaluations.
Used for audit trails and trace validation.
"""

from core.helix_error import ValidationError

class GovernanceLog:
    def __init__(self):
        self._entries = []

    def log(self, event: str, status: str):
        if not isinstance(event, str) or not isinstance(status, str):
            raise ValidationError("Event and status must be strings")
        self._entries.append((event, status))

    def dump(self):
        return self._entries

# Preserved test logic
def _test_governance_helix_log():
    l = GovernanceLog()
    l.log("audit", "pass")
    l.log("election", "fail")
    logs = l.dump()
    assert logs == [("audit", "pass"), ("election", "fail")]
    print("GovernanceLog tests: PASSED")

if __name__ == "__main__":
    _test_governance_helix_log()
