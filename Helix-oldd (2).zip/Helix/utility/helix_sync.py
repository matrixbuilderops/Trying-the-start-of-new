"""
Helix Utility Module: helix_sync

Controls synchronization markers across distributed logic nodes.
Used for tool and governance state alignment.
"""

from core.helix_error import ValidationError

class UtilitySync:
    def __init__(self):
        self._markers = {}

    def set_marker(self, key: str, value: bool):
        if not isinstance(key, str) or not isinstance(value, bool):
            raise ValidationError("Sync requires string key and boolean value")
        self._markers[key] = value

    def check(self, key: str):
        if key not in self._markers:
            raise ValidationError(f"Sync marker '{key}' not found")
        return self._markers[key]

# Preserved test logic
def _test_utility_helix_sync():
    s = UtilitySync()
    s.set_marker("aligned", True)
    assert s.check("aligned") is True
    try:
        s.check("ghost")
    except ValidationError:
        print("UtilitySync tests: PASSED")

if __name__ == "__main__":
    _test_utility_helix_sync()
