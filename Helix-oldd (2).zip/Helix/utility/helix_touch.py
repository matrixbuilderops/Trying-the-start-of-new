"""
Helix Utility Module: helix_touch

Ping utility to signal active files, scripts, and modules.
Used for integrity probing and health signaling.
"""

from core.helix_error import ValidationError

class UtilityTouch:
    def __init__(self):
        self._registry = {}

    def ping(self, key: str):
        if not isinstance(key, str):
            raise ValidationError("Ping key must be string")
        self._registry[key] = "active"

    def status(self, key: str):
        if key not in self._registry:
            raise ValidationError(f"No ping for '{key}'")
        return self._registry[key]

# Preserved test logic
def _test_utility_helix_touch():
    t = UtilityTouch()
    t.ping("module.alpha")
    assert t.status("module.alpha") == "active"
    try:
        t.status("ghost")
    except ValidationError:
        print("UtilityTouch tests: PASSED")

if __name__ == "__main__":
    _test_utility_helix_touch()
