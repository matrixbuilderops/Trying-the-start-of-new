from Helix.shell.helix_init import initialize_helix
from Helix.shell.helix_main import run_main

if __name__ == "__main__":
    initialize_helix()
    run_main()
