from Helix.core.helix_error import HelixError

def run_main():
    print("[Helix] Main execution started.")
    try:
        print("[Helix] Execution chain validated. Proceeding.")
    except HelixError as e:
        print(f"[Helix Main] Execution error: {e}")
