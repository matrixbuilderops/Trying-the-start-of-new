#META-BEGIN
{
  "Tool": "Health Monitor Script.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-f2f9b97e71ef93d4",
  "LastUpdated": "2025-06-23T01:54:14.311851",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# QTL_ID: QTLHealthMonitor_003
# Name: Health Monitor
# Purpose: Evaluates systemic health status of every tool file and flags broken hooks
# Hook: QTLHook::SystemCheck
# Harness: TestHarness::LiveVitals

import os

def monitor_health(directory):
    report = {}
    for fname in os.listdir(directory):
        if fname.endswith('.py'):
            with open(os.path.join(directory, fname), 'r') as file:
                content = file.read()
            if "def" not in content or "QTLHook" not in content:
                report[fname] = "❌ Incomplete"
            else:
                report[fname] = "✅ OK"
    return report

