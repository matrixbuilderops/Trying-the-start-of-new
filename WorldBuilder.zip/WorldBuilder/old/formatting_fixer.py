#META-BEGIN
{
  "Tool": "formatting_fixer.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-d04462050109f780",
  "LastUpdated": "2025-06-23T01:54:14.315859",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END

import os
import re
from pathlib import Path

def normalize_qtl_files(root_dir):
    qtl_files = Path(root_dir).rglob("*.qtl")
    for file_path in qtl_files:
        lines = file_path.read_text().splitlines()
        modified_lines = []
        has_test = False
        has_meta = any("@meta" in line for line in lines)

        for line in lines:
            # Normalize @use syntax
            if line.strip().startswith("use:"):
                line = line.replace("use:", "@use")

            # Normalize hook keyword
            if re.match(r'^hook\s', line.strip()):
                line = line.replace("hook", "@hook")

            # Ensure metadata block exists
            modified_lines.append(line)

            # Detect test block
            if "[TEST]" in line:
                has_test = True

        # Add default @meta block if missing
        if not has_meta:
            modified_lines.insert(0, "@meta UUID: AUTO-GENERATED")

        # Inject test block if missing
        if not has_test:
            modified_lines.append("\n[TEST]")
            modified_lines.append("assert true // default test")

        # Write file back
        file_path.write_text("\n".join(modified_lines))

if __name__ == "__main__":
    normalize_qtl_files(".")
    print("Formatting and metadata normalization complete.")
