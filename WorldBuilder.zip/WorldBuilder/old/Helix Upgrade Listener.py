#META-BEGIN
{
  "Tool": "Helix Upgrade Listener.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-16e1cf757680f8e4",
  "LastUpdated": "2025-06-23T01:54:14.315689",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# QTL-Validated | HelixUpgradeListener
# Listens for system-wide upgrade requests and initializes handoff to appropriate Upgrader Relay

from HelixBackend import HelixValidator
from VaultInterface import AuthToken
from UpgradeQueue import UpgradeInstruction

class HelixUpgradeListener:
    def __init__(self):
        self.token = AuthToken.load()
        self.validator = HelixValidator()
        self.queue = []

    def receive_upgrade_request(self, request_packet):
        if not request_packet or "toolset" not in request_packet:
            return {"status": "rejected", "reason": "invalid packet"}
        self.queue.append(request_packet)
        return {"status": "received", "id": request_packet.get("uid", "none")}

    def dispatch_queue(self):
        responses = []
        for instruction in self.queue:
            if self.validator.validate_instruction(instruction):
                response = self._initiate_upgrade(instruction)
                responses.append(response)
            else:
                responses.append({"status": "failed validation", "uid": instruction.get("uid", "none")})
        self.queue.clear()
        return responses

    def _initiate_upgrade(self, instruction):
        from ToolsetUpgraderRelay import Relay
        relay = Relay(instruction)
        return relay.execute()

if __name__ == "__main__":
    listener = HelixUpgradeListener()
    incoming = UpgradeInstruction.pull_pending()
    for item in incoming:
        listener.receive_upgrade_request(item)
    print(listener.dispatch_queue())

