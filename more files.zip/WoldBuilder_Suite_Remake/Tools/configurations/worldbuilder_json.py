"""
worldbuilder_json.py — JSON read/write handler for WorldBuilderSuite.
"""

import json

def write_json(directory: str, filename: str, data: object):
    path = f"{directory}/{filename}"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def load_json(directory: str, filename: str) -> object:
    path = f"{directory}/{filename}"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

