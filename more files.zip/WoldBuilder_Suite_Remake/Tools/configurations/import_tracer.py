"""
worldbuilder.import_tracer
Tracks and validates dynamic imports across the toolchain.
"""
import importlib.util
from typing import List

def trace_imports(modules: List[str]) -> dict:
    result = {}
    for module in modules:
        spec = importlib.util.find_spec(module)
        result[module] = spec is not None
    return result
