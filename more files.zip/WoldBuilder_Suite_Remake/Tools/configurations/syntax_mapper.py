"""
worldbuilder.syntax_mapper
Handles token transformations for code analysis.
"""
def map_syntax(code: str) -> list:
    return code.replace('(', ' ( ').replace(')', ' ) ').split()
