"""
worldbuilder.constraint_solver
Implements validation and logical constraint enforcement.
"""
def check_constraints(data: dict, constraints: dict) -> bool:
    return all(data.get(key) == value for key, value in constraints.items())
