"""
json_utils.py — Centralized JSON Handler
"""
import json
from typing import Any


def json_load(path: str) -> Any:
    """
    Load JSON data from a file.

    Args:
        path (str): Path to the JSON file.

    Returns:
        Any: Parsed JSON data.
    """
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def json_dump(data: Any, path: str) -> None:
    """
    Dump data to a JSON file.

    Args:
        data (Any): Data to serialize.
        path (str): Output file path.
    """
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

