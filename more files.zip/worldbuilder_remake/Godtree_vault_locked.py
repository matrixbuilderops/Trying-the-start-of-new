"""
GodTree — QTL-Bound Tool with Full CLI and Output Infrastructure
"""
import argparse
import datetime
import sys

from Configurations.worldbuilder_validate import qtl_validate_godtree
from Configurations.worldbuilder_cli import run_cli_menu
from Configurations.worldbuilder_runner import run_godtree_tool
from Configurations.worldbuilder_diagnostics import generate_diagnostic_report
from Configurations.worldbuilder_path import ensure_output_structure
from Configurations.worldbuilder_snapshot import record_tool_snapshot


def main() -> None:
    """
    Main execution logic for GodTree — supports CLI flags and menu.
    """
    tool_name = "godtree"
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    # QTL check (tool-unique, inline signature logic inside qtl_validate_godtree)
    qtl = qtl_validate_godtree(requester="user", command="cli_entry", timestamp=timestamp)
    if not qtl["approved"]:
        print(f"[QTL BLOCKED] {qtl['reason']}")
        sys.exit(1)

    # Setup output, diagnostics, backup, and log folders
    ensure_output_structure(tool_name=tool_name, timestamp=timestamp)

    # Parse CLI args
    parser = argparse.ArgumentParser(description="GodTree Execution Tool")
    parser.add_argument("--run", action="store_true", help="Run GodTree map builder")
    parser.add_argument("--diagnose", action="store_true", help="Run GodTree diagnostics")
    args = parser.parse_args()

    if args.run:
        print("[Running GodTree Tool]")
        run_godtree_tool(timestamp=timestamp)
        record_tool_snapshot(tool_name, timestamp)
        return

    if args.diagnose:
        print("[Running GodTree Diagnostics]")
        generate_diagnostic_report(tool_name, timestamp)
        record_tool_snapshot(tool_name, timestamp)
        return

    # If no flags used, launch CLI menu
    while True:
        print("\n[GodTree CLI Menu]")
        print("[1] Run Tool")
        print("[2] Run Diagnostics")
        print("[3] Exit")
        choice = input("Select an option: ").strip()

        if choice == "1":
            run_godtree_tool(timestamp=timestamp)
            record_tool_snapshot(tool_name, timestamp)
        elif choice == "2":
            generate_diagnostic_report(tool_name, timestamp)
            record_tool_snapshot(tool_name, timestamp)
        elif choice == "3":
            print("Exiting GodTree.")
            break
        else:
            print("Invalid option. Please select 1, 2, or 3.")


if __name__ == "__main__":
    main()

