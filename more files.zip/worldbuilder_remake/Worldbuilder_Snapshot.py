"""
worldbuilder_snapshot.py — Global Snapshot Logger for Tools
"""
from typing import Any, Dict

from Configurations.json_utils import json_load, json_dump
from Configurations.os_utils import ensure_dir_exists, get_dirname, file_exists
from Configurations.worldbuilder_path import build_snapshot_paths
from Configurations.worldbuilder_logger import log_event


def record_tool_snapshot(tool_name: str, timestamp: str, payload: Dict[str, Any] = None) -> None:
    """
    Save a JSON snapshot of tool execution state and merge into global ledger.

    Args:
        tool_name (str): Name of the tool (e.g., 'godtree').
        timestamp (str): Execution timestamp.
        payload (Dict[str, Any], optional): Additional data to snapshot.
    """
    if payload is None:
        payload = {
            "tool": tool_name,
            "timestamp": timestamp,
            "status": "complete"
        }

    tool_log_path, full_snapshot_path = build_snapshot_paths(tool_name, timestamp)
    ensure_dir_exists(get_dirname(tool_log_path))

    try:
        json_dump(payload, tool_log_path)

        merged_data = {}
        if file_exists(full_snapshot_path):
            merged_data = json_load(full_snapshot_path)

        merged_data[tool_name] = payload
        json_dump(merged_data, full_snapshot_path)

        log_event(tool_name, f"Snapshot written and merged at {timestamp}.")

    except Exception as e:
        log_event(tool_name, f"Snapshot failed at {timestamp}: {str(e)}")
        raise

