"""
os_utils.py — OS Operation Abstractions
"""
import os


def ensure_dir_exists(path: str) -> None:
    """
    Create directory if it does not exist.

    Args:
        path (str): Directory path.
    """
    os.makedirs(path, exist_ok=True)


def get_dirname(path: str) -> str:
    """
    Get the directory name from a file path.

    Args:
        path (str): File path.

    Returns:
        str: Directory component of the path.
    """
    return os.path.dirname(path)


def file_exists(path: str) -> bool:
    """
    Check if a file exists.

    Args:
        path (str): File path.

    Returns:
        bool: True if file exists, False otherwise.
    """
    return os.path.exists(path)

