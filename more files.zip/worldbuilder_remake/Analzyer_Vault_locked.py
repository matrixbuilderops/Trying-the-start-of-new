"""
Analyzer — QTL-Bound Clean-Room Tool with Dual CLI and Output Infra
"""
from Configurations.worldbuilder_validate import qtl_validate_analyzer, qtl_exit_if_blocked
from Configurations.worldbuilder_cli import parse_cli_args, cli_menu
from Configurations.worldbuilder_runner import run_analyzer_tool
from Configurations.worldbuilder_diagnostics import generate_diagnostic_report
from Configurations.worldbuilder_path import ensure_output_structure, current_timestamp
from Configurations.worldbuilder_snapshot import record_tool_snapshot


def main() -> None:
    """
    Main execution logic for Analyzer — supports CLI flags and menu.
    """
    tool_name = "analyzer"
    timestamp = current_timestamp()

    # QTL check (tool-unique, inline signature logic inside qtl_validate_analyzer)
    qtl = qtl_validate_analyzer(requester="user", command="cli_entry", timestamp=timestamp)
    qtl_exit_if_blocked(qtl)

    # Setup output, diagnostics, backup, and log folders
    ensure_output_structure(tool_name=tool_name, timestamp=timestamp)

    # Parse CLI args
    args = parse_cli_args(tool_name)

    if args.run:
        print("[Running Analyzer Tool]")
        run_analyzer_tool(timestamp=timestamp)
        record_tool_snapshot(tool_name, timestamp)
        return

    if args.diagnose:
        print("[Running Analyzer Diagnostics]")
        generate_diagnostic_report(tool_name, timestamp)
        record_tool_snapshot(tool_name, timestamp)
        return

    # If no flags used, launch CLI menu
    while True:
        cli_menu(tool_name, timestamp)


if __name__ == "__main__":
    main()

