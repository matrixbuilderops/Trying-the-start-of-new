#META-BEGIN
{
  "Tool": "StencilAI.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-58d74ebbc0b3a48f",
  "LastUpdated": "2025-06-23T01:54:14.310978",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# StencilAI.py – Adds standardized control surfaces and flag interfaces
def apply_stencil(app_blueprint, controls):
    app_blueprint["interface"] = {
        "flags": controls.get("flags", []),
        "modes": controls.get("modes", ["default"]),
        "entry": controls.get("entry", "main")
    }
    return app_blueprint