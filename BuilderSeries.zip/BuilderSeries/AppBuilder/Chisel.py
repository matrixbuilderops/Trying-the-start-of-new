#META-BEGIN
{
  "Tool": "Chisel.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-ac05e515ac54f25b",
  "LastUpdated": "2025-06-23T01:54:14.310933",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# Chisel.py – Cuts and shapes application modules from toolset-level definitions
def chisel_module(toolset_definition):
    core_structure = {
        "name": toolset_definition.get("name", "UnnamedApp"),
        "modules": [],
        "dependencies": []
    }
    for mod in toolset_definition.get("modules", []):
        core_structure["modules"].append({
            "id": mod["id"],
            "description": mod.get("desc", ""),
            "hooks": mod.get("hooks", [])
        })
    return core_structure