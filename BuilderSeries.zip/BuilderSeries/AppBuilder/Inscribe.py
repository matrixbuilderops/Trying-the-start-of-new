#META-BEGIN
{
  "Tool": "Inscribe.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-3c15e245dff636f4",
  "LastUpdated": "2025-06-23T01:54:14.311019",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# Inscribe.py – Writes metadata and registry info into app builds
def inscribe_metadata(app_structure, registry):
    app_structure["metadata"] = {
        "author": registry.get("author", "unknown"),
        "version": registry.get("version", "0.1.0"),
        "toolchain": registry.get("toolchain", []),
        "license": registry.get("license", "Unspecified")
    }
    return app_structure