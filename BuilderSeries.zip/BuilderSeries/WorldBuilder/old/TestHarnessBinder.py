#META-BEGIN
{
  "Tool": "TestHarnessBinder.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-fe2feb8833f31695",
  "LastUpdated": "2025-06-23T01:54:14.315803",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
import os
import re

def construct_test_block(file_name):
    tool_id = file_name.replace(".qtl", "")
    return [
        "#TEST: Begin",
        f"#TEST: Target={tool_id}",
        "#TEST: Harness=TestHarness/TestHarness.qtl",
        f"#TEST: Diagnostic=Diagnostics/{tool_id}_diagnostic.txt",
        "#TEST: Execute=test_main",
        "#TEST: Block=[Default minimal logic. Extend in file-specific test upgrade.]",
        "#TEST: End"
    ]

def remove_existing_test_block(lines):
    new_lines = []
    skip = False
    for line in lines:
        if line.strip().startswith("#TEST: Begin"):
            skip = True
        if not skip:
            new_lines.append(line)
        if line.strip().startswith("#TEST: End"):
            skip = False
    return new_lines

def update_test_block(file_path):
    with open(file_path, 'r') as f:
        lines = f.read().splitlines()

    lines_cleaned = remove_existing_test_block(lines)
    test_block = construct_test_block(os.path.basename(file_path))
    updated_content = "\n".join(lines_cleaned + [""] + test_block)

    with open(file_path, 'w') as f:
        f.write(updated_content)

def process_all_qtl_files(root_dir):
    for subdir, _, files in os.walk(root_dir):
        for filename in files:
            if filename.endswith(".qtl"):
                full_path = os.path.join(subdir, filename)
                update_test_block(full_path)

if __name__ == "__main__":
    ROOT_DIRECTORY = "./"  # Adjust to your directory as needed
    process_all_qtl_files(ROOT_DIRECTORY)

