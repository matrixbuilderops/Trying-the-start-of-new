#META-BEGIN
{
  "Tool": "upgrade_applier.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-2fae438c404b4b57",
  "LastUpdated": "2025-06-23T01:54:14.315558",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END

import os
from pathlib import Path

def inject_level_207_upgrades(root_dir):
    qtl_files = list(Path(root_dir).rglob("*.qtl"))
    upgrade_targets = [
        "Validator.qtl", "Helix_Backend.qtl", "Guardian.qtl",
        "QTL.qtl", "Vault.qtl", "Patchline.qtl"
    ]

    for path in qtl_files:
        if any(path.name == target for target in upgrade_targets):
            content = path.read_text()
            if "@upgrade" not in content:
                content += "\n\n[UPGRADE]\n"
                content += "enable_chainlink_validation = true\n"
                content += "inject_entropy_trace = true\n"
                content += "fork_council_enabled = true\n"
                content += "quantum_lock = true"
                path.write_text(content)

if __name__ == "__main__":
    inject_level_207_upgrades(".")
    print("Level 207 upgrades applied to applicable files.")
