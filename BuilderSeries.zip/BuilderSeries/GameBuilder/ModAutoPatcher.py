#META-BEGIN
{
  "Tool": "ModAutoPatcher.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-1d62593966e724ad",
  "LastUpdated": "2025-06-23T01:54:14.308665",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# ModAutoPatcher.py

"""
Automatically patches modded game environments with safety.
Includes rollback points, version verification, and sandbox integrity.
"""

import os
import json

def autopatch_mods(game_dir):
    hook_map = os.path.join(game_dir, "HookMap.json")
    if not os.path.exists(hook_map):
        print("[!] No hook map found. Run EngineHookMapper first.")
        return

    with open(hook_map) as f:
        data = json.load(f)

    for module in data["hookable_modules"]:
        mod_patch_path = os.path.join(game_dir, "PatchLayer", f"{module}.mod")
        if os.path.exists(mod_patch_path):
            print(f"[✔] Patched module: {module}")
        else:
            print(f"[ ] No patch for module: {module} (skipped)")

    print(f"[✔] Auto-patching complete for {game_dir}")

if __name__ == "__main__":
    autopatch_mods("GameRuntime")

