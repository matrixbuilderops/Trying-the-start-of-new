#META-BEGIN
{
  "Tool": "SuccessorGenerator.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-a01a4b9d5c669839",
  "LastUpdated": "2025-06-23T01:54:14.308751",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
import shutil
import os

def generate_successor_environment(base_game_dir, output_dir, version_suffix="_v2"):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for item in os.listdir(base_game_dir):
        s = os.path.join(base_game_dir, item)
        d = os.path.join(output_dir, f"{item}{version_suffix}")
        if os.path.isdir(s):
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)
    print(f"Successor environment generated at: {output_dir}")

