#META-BEGIN
{
  "Tool": "EngineHookMapper.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-254b617d4f05d3ab",
  "LastUpdated": "2025-06-23T01:54:14.307801",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# EngineHookMapper.py

"""
Scans a game runtime to detect accessible engine points.
Generates a list of hookable modules and safe injection targets.
"""

import os
import json

def map_engine_hooks(game_runtime_dir):
    engine_hooks = []
    candidates = ["render", "physics", "audio", "ui", "input", "net"]

    for item in os.listdir(game_runtime_dir):
        if any(c in item.lower() for c in candidates):
            engine_hooks.append(item)

    out_path = os.path.join(game_runtime_dir, "HookMap.json")
    with open(out_path, 'w') as f:
        json.dump({"hookable_modules": engine_hooks}, f, indent=4)
    
    print(f"[✔] Hook map generated at {out_path}")

if __name__ == "__main__":
    map_engine_hooks("GameRuntime")

