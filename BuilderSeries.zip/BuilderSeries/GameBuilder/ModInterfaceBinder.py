#META-BEGIN
{
  "Tool": "ModInterfaceBinder.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-96ce3355a37b1f91",
  "LastUpdated": "2025-06-23T01:54:14.310089",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
# ModInterfaceBinder.py

"""
Binds approved mod packages into a running game session.
Handles QTL-safe patch layers and runtime overlays.
"""

import os
import shutil

def bind_mod_interface(game_dir, mod_package_dir, bind_target="PatchLayer"):
    patch_dir = os.path.join(game_dir, bind_target)
    os.makedirs(patch_dir, exist_ok=True)
    
    for mod_file in os.listdir(mod_package_dir):
        source = os.path.join(mod_package_dir, mod_file)
        dest = os.path.join(patch_dir, mod_file)
        shutil.copyfile(source, dest)
    
    print(f"[✔] Mod package from {mod_package_dir} bound to {patch_dir}")

if __name__ == "__main__":
    bind_mod_interface("GameRuntime", "UserMods/SuperJumpMod")

