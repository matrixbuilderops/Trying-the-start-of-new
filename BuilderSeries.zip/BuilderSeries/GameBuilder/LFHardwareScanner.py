#META-BEGIN
{
  "Tool": "LFHardwareScanner.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-5285e61db77d6d57",
  "LastUpdated": "2025-06-23T01:54:14.307202",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
import platform
import psutil

def scan_hardware_profile():
    profile = {
        "os": platform.system(),
        "cpu": platform.processor(),
        "ram_gb": round(psutil.virtual_memory().total / (1024**3), 2),
        "core_count": psutil.cpu_count(logical=False),
        "logical_cores": psutil.cpu_count(logical=True),
        "disk_space_gb": round(psutil.disk_usage('/').total / (1024**3), 2),
    }
    print("Hardware Profile Detected:")
    for k, v in profile.items():
        print(f"  {k}: {v}")
    return profile

