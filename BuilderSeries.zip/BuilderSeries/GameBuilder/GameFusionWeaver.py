#META-BEGIN
{
  "Tool": "GameFusionWeaver.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-12e5feca8b264925",
  "LastUpdated": "2025-06-23T01:54:14.308964",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
import json

def fuse_game_templates(template_a_path, template_b_path, output_path):
    with open(template_a_path, 'r') as f1, open(template_b_path, 'r') as f2:
        a_data = json.load(f1)
        b_data = json.load(f2)
    
    fused = {**a_data, **b_data}
    fused['fusion_origin'] = [a_data.get('name', 'templateA'), b_data.get('name', 'templateB')]
    
    with open(output_path, 'w') as out:
        json.dump(fused, out, indent=2)
    
    print(f"Fused template saved to: {output_path}")

