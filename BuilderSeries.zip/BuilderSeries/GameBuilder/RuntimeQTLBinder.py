#META-BEGIN
{
  "Tool": "RuntimeQTLBinder.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-f5dd62a83e4ad466",
  "LastUpdated": "2025-06-23T01:54:14.308622",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
import os

def bind_qtl_patch(runtime_dir, patch_qtl_path):
    with open(patch_qtl_path, 'r') as patch_file:
        patch_data = patch_file.read()
    
    runtime_patch_file = os.path.join(runtime_dir, "runtime_patch.qtl")
    with open(runtime_patch_file, 'w') as out_file:
        out_file.write(patch_data)
    
    print(f"QTL patch bound to runtime at: {runtime_patch_file}")

