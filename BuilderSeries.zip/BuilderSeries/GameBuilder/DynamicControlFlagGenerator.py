#META-BEGIN
{
  "Tool": "DynamicControlFlagGenerator.py",
  "Version": "1.0.0",
  "QTLIdentifier": "QTLID-0d457e53a03070e6",
  "LastUpdated": "2025-06-23T01:54:14.307094",
  "Hook": "Hook:TestHarness",
  "ChainLink": true,
  "Encrypted": false,
  "SelfContained": true
}
#META-END
import uuid
import random

def generate_flag(context, user_profile=None):
    base = str(uuid.uuid4()).split('-')[0]
    entropy = random.randint(100, 999)
    user_tag = user_profile["user_id"][:4] if user_profile else "anon"
    flag = f"FLAG_{context.upper()}_{user_tag}_{base}_{entropy}"
    print(f"Generated dynamic control flag: {flag}")
    return flag

