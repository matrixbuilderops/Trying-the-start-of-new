import os
import json

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(ROOT_DIR, "Configuration")
REGISTRY_PATH = os.path.join(CONFIG_DIR, "ChainLinkRegistry.json")

def generate_chainlink_registry():
    # Dummy registry structure - replace this with actual logic later
    registry = {
        "Toolset": "WorldBuilder",
        "Hooks": {
            "QTL": True,
            "Test": True,
            "ChainLink": True
        },
        "LinkedFiles": []
    }

    # Ensure Configuration directory exists
    os.makedirs(CONFIG_DIR, exist_ok=True)

    with open(REGISTRY_PATH, "w") as file:
        json.dump(registry, file, indent=4)

    print(f"✅ ChainLink Registry saved to: {REGISTRY_PATH}")

if __name__ == "__main__":
    generate_chainlink_registry()