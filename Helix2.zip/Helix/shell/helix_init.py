from Helix.core.helix_error import HelixError
from Helix.tools.helix_guard import validate_tool
from Helix.governance.helix_scope import PermissionScope

def initialize_helix():
    print("[Helix] Initialization started.")
    try:
        validate_tool()
        scope = PermissionScope()
        scope.allow("core", "tools", "governance", "utility")
        print("[Helix] Initialization complete.")
    except HelixError as e:
        print(f"[Helix Init] Error during initialization: {e}")
