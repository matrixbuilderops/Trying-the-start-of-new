"""
Helix Governance Module: helix_registry

Tracks and validates authorized modules and trusted entity maps.
Used for role-based enforcement and governance control.
"""

from core.helix_error import ScopeViolation

class GovernanceRegistry:
    def __init__(self):
        self._map = {}

    def authorize(self, role: str, logic):
        if not callable(logic):
            raise ScopeViolation("Registry logic must be callable")
        self._map[role] = logic

    def resolve(self, role: str, *args, **kwargs):
        if role not in self._map:
            raise ScopeViolation(f"Role '{role}' not defined in registry")
        return self._map[role](*args, **kwargs)

# Preserved test logic
def _test_governance_helix_registry():
    r = GovernanceRegistry()
    r.authorize("moderator", lambda x: f"Access {x}")
    assert r.resolve("moderator", "granted") == "Access granted"
    try:
        r.resolve("ghost")
    except ScopeViolation:
        print("GovernanceRegistry tests: PASSED")

if __name__ == "__main__":
    _test_governance_helix_registry()
