"""
Helix Governance Module: helix_policy

Central authority for defining and accessing global governance policy flags.
Supports enforcement logic and role-based flags.
"""

from core.helix_error import ValidationError

class GovernancePolicy:
    def __init__(self):
        self._flags = {}

    def define(self, key: str, value):
        if not isinstance(key, str):
            raise ValidationError("Policy key must be string")
        self._flags[key] = value

    def get(self, key: str):
        if key not in self._flags:
            raise ValidationError(f"Policy '{key}' not defined")
        return self._flags[key]

# Preserved test logic
def _test_governance_helix_policy():
    p = GovernancePolicy()
    p.define("audit", True)
    assert p.get("audit") is True
    try:
        p.get("shadow")
    except ValidationError:
        print("GovernancePolicy tests: PASSED")

if __name__ == "__main__":
    _test_governance_helix_policy()
