"""
Helix Governance Module: helix_compile

Compiles rules and decision nodes for authority validation structures.
Transforms node logic into governance workflows.
"""

from core.helix_error import ScopeViolation

class GovernanceCompiler:
    def __init__(self):
        self._compiled = {}

    def compile(self, label: str, fn):
        if not callable(fn):
            raise ScopeViolation("Governance unit must be callable")
        self._compiled[label] = fn

    def evaluate(self, label: str, *args, **kwargs):
        if label not in self._compiled:
            raise ScopeViolation(f"Compiled node '{label}' not found")
        return self._compiled[label](*args, **kwargs)

# Preserved test logic
def _test_governance_helix_compile():
    g = GovernanceCompiler()
    g.compile("approve", lambda x: x > 0)
    assert g.evaluate("approve", 3) is True
    try:
        g.evaluate("reject")
    except ScopeViolation:
        print("GovernanceCompiler tests: PASSED")

if __name__ == "__main__":
    _test_governance_helix_compile()
