"""
Helix Utility Module: helix_cache

Ephemeral key-value cache for short-lived logic references.
Used to store intermediate logic states.
"""

from core.helix_error import ValidationError

class UtilityCache:
    def __init__(self):
        self._store = {}

    def set(self, key: str, value):
        if not isinstance(key, str):
            raise ValidationError("Cache key must be string")
        self._store[key] = value

    def get(self, key: str):
        if key not in self._store:
            raise ValidationError(f"Cache key '{key}' not found")
        return self._store[key]

# Preserved test logic
def _test_utility_helix_cache():
    c = UtilityCache()
    c.set("token", 123)
    assert c.get("token") == 123
    try:
        c.get("ghost")
    except ValidationError:
        print("UtilityCache tests: PASSED")

if __name__ == "__main__":
    _test_utility_helix_cache()
