"""
Helix Utility Module: helix_vault

Stores critical logic objects and secure memory bindings.
Used for non-exportable runtime logic.
"""

from core.helix_error import ValidationError

class UtilityVault:
    def __init__(self):
        self._secure = {}

    def lock(self, key: str, secret):
        if not isinstance(key, str):
            raise ValidationError("Vault key must be a string")
        self._secure[key] = secret

    def unlock(self, key: str):
        if key not in self._secure:
            raise ValidationError(f"No vault entry for '{key}'")
        return self._secure[key]

# Preserved test logic
def _test_utility_helix_vault():
    v = UtilityVault()
    v.lock("corekey", "secret123")
    assert v.unlock("corekey") == "secret123"
    try:
        v.unlock("ghost")
    except ValidationError:
        print("UtilityVault tests: PASSED")

if __name__ == "__main__":
    _test_utility_helix_vault()
