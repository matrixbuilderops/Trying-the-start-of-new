"""
Helix Utility Module: helix_temp

Stores temporary logic objects for volatile reference.
Auto-clears on session shutdown or manual purge.
"""

from core.helix_error import ValidationError

class UtilityTemp:
    def __init__(self):
        self._temp = {}

    def hold(self, key: str, obj):
        if not isinstance(key, str):
            raise ValidationError("Temp key must be a string")
        self._temp[key] = obj

    def fetch(self, key: str):
        if key not in self._temp:
            raise ValidationError(f"Temp object '{key}' not found")
        return self._temp[key]

    def purge(self):
        self._temp.clear()

# Preserved test logic
def _test_utility_helix_temp():
    t = UtilityTemp()
    t.hold("alpha", 42)
    assert t.fetch("alpha") == 42
    t.purge()
    try:
        t.fetch("alpha")
    except ValidationError:
        print("UtilityTemp tests: PASSED")

if __name__ == "__main__":
    _test_utility_helix_temp()
