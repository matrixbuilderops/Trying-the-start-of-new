"""
Helix Utility Module: helix_flag

Sets runtime flags and toggles for conditional logic branches.
Supports temporary feature gates.
"""

from core.helix_error import ValidationError

class UtilityFlag:
    def __init__(self):
        self._flags = {}

    def set(self, key: str, value: bool):
        if not isinstance(key, str) or not isinstance(value, bool):
            raise ValidationError("Flag must use a string key and boolean value")
        self._flags[key] = value

    def get(self, key: str):
        if key not in self._flags:
            raise ValidationError(f"Flag '{key}' not set")
        return self._flags[key]

# Preserved test logic
def _test_utility_helix_flag():
    f = UtilityFlag()
    f.set("debug", True)
    assert f.get("debug") is True
    try:
        f.get("ghost")
    except ValidationError:
        print("UtilityFlag tests: PASSED")

if __name__ == "__main__":
    _test_utility_helix_flag()
