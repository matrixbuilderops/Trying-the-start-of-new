"""
Helix Tools Module: helix_compile

Compiles unstructured logic units into standardized tool modules.
Performs structural transformation and binding.
"""

from core.helix_error import ValidationError

class ToolCompiler:
    def __init__(self):
        self._compiled = {}

    def compile(self, name: str, fn):
        if not callable(fn):
            raise ValidationError("Compile target must be callable")
        self._compiled[name] = fn

    def get(self, name: str):
        if name not in self._compiled:
            raise ValidationError(f"Logic '{name}' not found")
        return self._compiled[name]

# Preserved test logic
def _test_tools_helix_compile():
    c = ToolCompiler()
    c.compile("double", lambda x: x * 2)
    fn = c.get("double")
    assert fn(4) == 8
    print("ToolCompiler tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_compile()
