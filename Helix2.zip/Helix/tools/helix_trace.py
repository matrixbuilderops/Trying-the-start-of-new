"""
Helix Tools Module: helix_trace

Records function calls and execution metadata during tool runtime.
Used for diagnostics and rollback logging.
"""

from core.helix_error import ValidationError

class ToolTrace:
    def __init__(self):
        self._log = []

    def record(self, name: str, args: tuple, result):
        if not isinstance(name, str):
            raise ValidationError("Function name must be a string")
        self._log.append((name, args, result))

    def dump(self):
        return self._log

# Preserved test logic
def _test_tools_helix_trace():
    t = ToolTrace()
    t.record("add", (2, 3), 5)
    t.record("mul", (3, 4), 12)
    logs = t.dump()
    assert logs == [("add", (2, 3), 5), ("mul", (3, 4), 12)]
    print("ToolTrace tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_trace()
