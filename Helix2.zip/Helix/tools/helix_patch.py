"""
Helix Tools Module: helix_patch

Applies hotfixes or logic overrides within tool modules.
Used for dynamic updates without redeployment.
"""

from core.helix_error import ValidationError

class ToolPatch:
    def __init__(self, registry):
        self._registry = registry

    def patch(self, name: str, fn):
        if not callable(fn):
            raise ValidationError("Patch must be a callable object")
        self._registry[name] = fn

# Preserved test logic
def _test_tools_helix_patch():
    reg = {"step": lambda x: x + 1}
    p = ToolPatch(reg)
    p.patch("step", lambda x: x * 3)
    assert reg["step"](2) == 6
    print("ToolPatch tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_patch()
