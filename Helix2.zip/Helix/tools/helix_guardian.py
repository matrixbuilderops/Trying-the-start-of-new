"""
Helix Tools Module: helix_guardian

Supervises multi-stage toolchain execution and failure recovery.
Integrates patch, rollback, and policy enforcement.
"""

from core.helix_error import LogicBreach

class ToolGuardian:
    def __init__(self, fallback=None):
        self._fallback = fallback

    def protect(self, fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            if self._fallback:
                return self._fallback(e)
            raise LogicBreach(f"Toolchain failure: {e}")

# Preserved test logic
def _test_tools_helix_guardian():
    def risky(x): return 10 / x
    def rescue(e): return f"Recovered: {e}"

    g = ToolGuardian(fallback=rescue)
    assert g.protect(risky, 2) == 5
    assert g.protect(risky, 0).startswith("Recovered:")
    print("ToolGuardian tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_guardian()
