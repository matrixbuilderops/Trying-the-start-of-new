"""
Helix Tools Module: helix_policy

Defines operational rules and runtime flags for toolchain behavior.
Acts as centralized policy interface.
"""

from core.helix_error import ValidationError

class ToolPolicy:
    def __init__(self):
        self._flags = {}

    def define(self, key: str, value):
        self._flags[key] = value

    def query(self, key: str):
        if key not in self._flags:
            raise ValidationError(f"Policy key '{key}' not defined")
        return self._flags[key]

# Preserved test logic
def _test_tools_helix_policy():
    p = ToolPolicy()
    p.define("sandbox", True)
    assert p.query("sandbox") is True
    try:
        p.query("ghost")
    except ValidationError:
        print("ToolPolicy tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_policy()
