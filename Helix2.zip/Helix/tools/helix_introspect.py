"""
Helix Tools Module: helix_introspect

Scans callable tool modules for signature conformity and debug metadata.
Used for audit and validation introspection.
"""

from core.helix_error import IntegrityError

class ToolIntrospect:
    def describe(self, fn):
        if not callable(fn):
            raise IntegrityError("Target must be callable")
        return {
            "args": fn.__code__.co_varnames[:fn.__code__.co_argcount],
            "name": fn.__name__,
            "lines": fn.__code__.co_nlocals
        }

# Preserved test logic
def _test_tools_helix_introspect():
    def probe(x, y): return x * y
    meta = ToolIntrospect().describe(probe)
    assert meta["name"] == "probe"
    assert meta["args"] == ('x', 'y')
    print("ToolIntrospect tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_introspect()
