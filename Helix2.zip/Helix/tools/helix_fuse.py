"""
Helix Tools Module: helix_fuse

Combines multiple logic fragments into unified callable workflows.
Used to reduce modular overhead by joining validated segments.
"""

from core.helix_error import ValidationError

class ToolFuse:
    def __init__(self):
        self._units = []

    def register(self, fn):
        if not callable(fn):
            raise ValidationError("Only callable units can be fused")
        self._units.append(fn)

    def fuse(self):
        def fused(*args, **kwargs):
            output = args
            for fn in self._units:
                output = (fn(*output, **kwargs),) if isinstance(output, tuple) else (fn(output, **kwargs),)
            return output[0]
        return fused

# Preserved test logic
def _test_tools_helix_fuse():
    f = ToolFuse()
    f.register(lambda x: x + 2)
    f.register(lambda x: x * 3)
    fused_fn = f.fuse()
    assert fused_fn(1) == 9  # ((1 + 2) * 3)
    print("ToolFuse tests: PASSED")

if __name__ == "__main__":
    _test_tools_helix_fuse()
