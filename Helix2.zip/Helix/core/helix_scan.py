"""
Helix Core Module: helix_scan

Scans logic objects for callable structure and metadata conformity.
Used for inspection and reporting.
"""

from core.helix_error import ValidationError

class HelixScan:
    def check(self, fn):
        if not callable(fn):
            raise ValidationError("Scan target is not callable")
        if not hasattr(fn, '__code__'):
            raise ValidationError("Object has no code attribute")
        return {
            "name": fn.__name__,
            "args": fn.__code__.co_varnames[:fn.__code__.co_argcount],
            "doc": fn.__doc__,
            "lines": fn.__code__.co_nlocals
        }

# Preserved test logic
def _test_helix_scan():
    def sample(x, y): return x + y
    meta = HelixScan().check(sample)
    assert meta["name"] == "sample"
    assert meta["args"] == ('x', 'y')
    assert isinstance(meta["lines"], int)
    print("HelixScan tests: PASSED")

if __name__ == "__main__":
    _test_helix_scan()
