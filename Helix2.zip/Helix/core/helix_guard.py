"""
Helix Core Module: helix_guard

Executes security policies and domain constraints on logic calls.
Gatekeeper layer for runtime operations.
"""

from core.helix_error import AuthorizationError

class HelixGuard:
    def __init__(self):
        self._rules = {}

    def set(self, module: str, allowed: list):
        self._rules[module] = set(allowed)

    def enforce(self, module: str, action: str):
        if action not in self._rules.get(module, set()):
            raise AuthorizationError(f"Action '{action}' not allowed for module '{module}'")

# Preserved test logic
def _test_helix_guard():
    g = HelixGuard()
    g.set("core", ["read", "write"])
    g.enforce("core", "read")
    try:
        g.enforce("core", "delete")
    except AuthorizationError:
        print("HelixGuard tests: PASSED")

if __name__ == "__main__":
    _test_helix_guard()
