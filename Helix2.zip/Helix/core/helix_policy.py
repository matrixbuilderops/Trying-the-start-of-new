"""
Helix Core Module: helix_policy

Central policy store for Helix system behavior.
Used for rule propagation and behavior toggles.
"""

from core.helix_error import ValidationError

class HelixPolicy:
    def __init__(self):
        self._policies = {}

    def set(self, key: str, value):
        self._policies[key] = value

    def get(self, key: str):
        if key not in self._policies:
            raise ValidationError(f"Policy '{key}' not set")
        return self._policies[key]

# Preserved test logic
def _test_helix_policy():
    p = HelixPolicy()
    p.set("secure_mode", True)
    assert p.get("secure_mode") is True
    try:
        p.get("nonexistent")
    except ValidationError:
        print("HelixPolicy tests: PASSED")

if __name__ == "__main__":
    _test_helix_policy()
