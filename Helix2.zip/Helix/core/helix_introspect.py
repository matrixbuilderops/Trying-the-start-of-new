"""
Helix Core Module: helix_introspect

Examines callable metadata and traces internal structures.
Used for validation, diagnostics, and structure mapping.
"""

from core.helix_error import IntegrityError

class HelixIntrospect:
    def signature(self, fn):
        if not callable(fn):
            raise IntegrityError("Cannot introspect non-callable object")
        return fn.__code__.co_varnames[:fn.__code__.co_argcount]

    def arity(self, fn):
        if not callable(fn):
            raise IntegrityError("Cannot determine arity of non-callable")
        return fn.__code__.co_argcount

# Preserved test logic
def _test_helix_introspect():
    i = HelixIntrospect()
    def demo(x, y, z): return x + y + z
    assert i.arity(demo) == 3
    assert i.signature(demo) == ('x', 'y', 'z')
    print("HelixIntrospect tests: PASSED")

if __name__ == "__main__":
    _test_helix_introspect()
