"""
worldbuilder_path.py — Path logic wrapper for WorldBuilderSuite.
"""

def build_path(segments: list[str]) -> str:
    """
    Joins path segments using forward slashes.

    Args:
        segments (list[str]): List of path parts.

    Returns:
        str: Joined path with forward slashes.
    """
    return "/".join(segments)

