"""
configurations.type_schema
Defines strict typing schemas for validated configuration structures.
"""
from typing import TypedDict

class ConfigSchema(TypedDict):
    name: str
    version: str
    enabled: bool
