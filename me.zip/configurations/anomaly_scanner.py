"""
worldbuilder.anomaly_scanner
Scans for anomalies based on predefined rule sets.
"""
from typing import List

def scan(data: List[str], keywords: List[str]) -> List[str]:
    return [item for item in data if any(keyword in item for keyword in keywords)]
