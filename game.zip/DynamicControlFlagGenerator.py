import uuid
import random

def generate_flag(context, user_profile=None):
    base = str(uuid.uuid4()).split('-')[0]
    entropy = random.randint(100, 999)
    user_tag = user_profile["user_id"][:4] if user_profile else "anon"
    flag = f"FLAG_{context.upper()}_{user_tag}_{base}_{entropy}"
    print(f"Generated dynamic control flag: {flag}")
    return flag

