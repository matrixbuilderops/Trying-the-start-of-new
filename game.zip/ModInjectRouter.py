import json
import os

def inject_mod(game_runtime_path, mod_file_path):
    if not os.path.exists(game_runtime_path) or not os.path.exists(mod_file_path):
        raise FileNotFoundError("One or both paths do not exist.")
    
    with open(mod_file_path, 'r') as mod_file:
        mod_data = mod_file.read()

    injection_point = os.path.join(game_runtime_path, "live_mods", os.path.basename(mod_file_path))
    os.makedirs(os.path.dirname(injection_point), exist_ok=True)
    
    with open(injection_point, 'w') as injected_file:
        injected_file.write(mod_data)
    
    print(f"Injected mod into live runtime at: {injection_point}")

