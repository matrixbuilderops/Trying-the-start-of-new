import os

def bind_qtl_patch(runtime_dir, patch_qtl_path):
    with open(patch_qtl_path, 'r') as patch_file:
        patch_data = patch_file.read()
    
    runtime_patch_file = os.path.join(runtime_dir, "runtime_patch.qtl")
    with open(runtime_patch_file, 'w') as out_file:
        out_file.write(patch_data)
    
    print(f"QTL patch bound to runtime at: {runtime_patch_file}")

