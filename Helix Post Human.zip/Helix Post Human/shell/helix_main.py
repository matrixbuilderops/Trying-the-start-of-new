"""
Helix Shell Module: helix_main

Top-level entrypoint for the Helix system.
Loads modules, initializes governance, and begins system execution.
"""

def main():
    print("Booting Helix...")

    # Mocked components for standalone test
    class Dummy:
        def __init__(self, name): self.name = name
        def __call__(self, *a, **k): return f"Executed: {self.name}"
        def compile(self): return {"default": lambda: "ok"}
        def bind(self, reg): pass
        def execute(self, name, *a): return f"{name} executed"

    compiler = Dummy("compiler")
    builder = Dummy("builder")
    policy = Dummy("policy")
    registry = Dummy("registry")
    scope = Dummy("scope")
    law = Dummy("law")
    seal = Dummy("seal")
    warden = Dummy("warden")

    try:
        from helix_runner import HelixRunner
    except ImportError:
        # Local fallback for isolated test
        class HelixRunner:
            def __init__(self, *a): self.ctx = a
            def boot(self): print("Runner booted.")
            def invoke(self, *a): print("Runner invoked.")

    runner = HelixRunner(compiler, builder, policy, registry, scope, law, seal, warden)
    runner.boot()
    runner.invoke("default", {"mode": "safe"}, "return safe", "default", "core", "tools")

if __name__ == "__main__":
    main()
