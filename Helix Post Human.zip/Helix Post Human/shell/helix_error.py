"""
Helix Core Module: helix_error

Defines Helix-standard exceptions and system error codes.
Central error interface for all Helix modules.
"""

class HelixError(Exception): pass

class ValidationError(HelixError): pass
class AuthorizationError(HelixError): pass
class IntegrityError(HelixError): pass
class ScopeViolation(HelixError): pass
class LogicBreach(HelixError): pass

# Embedded test suite
def _test_helix_error():
    try:
        raise ValidationError("Test validation error")
    except ValidationError as e:
        assert "validation" in str(e)

    try:
        raise ScopeViolation("Test scope violation")
    except ScopeViolation as e:
        assert isinstance(e, HelixError)

    print("HelixError tests: PASSED")

if __name__ == "__main__":
    _test_helix_error()
