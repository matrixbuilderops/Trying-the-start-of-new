"""
Helix Governance Module: helix_seal

Locks validated modules against unauthorized mutation.
Provides system-level immutability enforcement via digital seal.
"""

import hashlib

class HelixSeal:
    def __init__(self):
        self._seals = {}

    def seal(self, name: str, content: str):
        digest = hashlib.sha256(content.encode()).hexdigest()
        self._seals[name] = digest

    def verify(self, name: str, content: str) -> bool:
        current = hashlib.sha256(content.encode()).hexdigest()
        return self._seals.get(name) == current

    def signature(self, name: str) -> str:
        return self._seals.get(name, "")

# Embedded test suite
def _test_helix_seal():
    s = HelixSeal()
    code = "def foo():\n    return 1"
    s.seal("foo_module", code)
    assert s.verify("foo_module", code)
    assert not s.verify("foo_module", code + "# tampered")
    assert s.signature("foo_module") != ""
    print("HelixSeal tests: PASSED")

if __name__ == "__main__":
    _test_helix_seal()
