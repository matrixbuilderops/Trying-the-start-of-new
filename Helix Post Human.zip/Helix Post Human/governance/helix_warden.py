"""
Helix Governance Module: helix_warden

Central execution control unit. Applies all governance rules and enforces final judgment.
Oversees law validation, seal integrity, and scope permissions.
"""

class HelixWarden:
    def __init__(self, laws, seals, scopes):
        self._laws = laws
        self._seals = seals
        self._scopes = scopes

    def authorize(self, caller: str, callee: str, context: dict, content: str, seal_name: str) -> bool:
        scope_ok = self._scopes.allowed(caller, callee)
        law_ok = self._laws.evaluate(context)
        seal_ok = self._seals.verify(seal_name, content)
        return scope_ok and law_ok and seal_ok

# Corrected test with functional seal mock
def _test_helix_warden():
    class MockScope:
        def allowed(self, caller, callee): return caller == "core" and callee == "tools"

    class MockLaws:
        def evaluate(self, ctx): return ctx.get("mode") == "safe"

    class MockSeals:
        def verify(self, name, content): return "unsafe" not in content

    w = HelixWarden(MockLaws(), MockSeals(), MockScope())
    assert w.authorize("core", "tools", {"mode": "safe"}, "def foo(): return 'safe'", "mod")
    assert not w.authorize("core", "tools", {"mode": "unsafe"}, "def foo(): return 'safe'", "mod")
    assert not w.authorize("core", "utils", {"mode": "safe"}, "def foo(): return 'safe'", "mod")
    assert not w.authorize("core", "tools", {"mode": "safe"}, "def foo(): return 'unsafe'", "mod")
    print("HelixWarden tests: PASSED")

if __name__ == "__main__":
    _test_helix_warden()
