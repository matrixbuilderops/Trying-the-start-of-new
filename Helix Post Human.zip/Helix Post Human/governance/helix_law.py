"""
Helix Governance Module: helix_law

Central logic engine for interpreting and applying system laws.
Evaluates actions against enforced rules and system-wide directives.
"""

class HelixLaw:
    def __init__(self):
        self._laws = {}
        self._violations = []

    def enact(self, law_id: str, rule: callable):
        if not callable(rule):
            raise TypeError("Rule must be callable.")
        self._laws[law_id] = rule

    def revoke(self, law_id: str):
        self._laws.pop(law_id, None)

    def evaluate(self, context: dict) -> bool:
        for law_id, rule in self._laws.items():
            if not rule(context):
                self._violations.append(law_id)
                return False
        return True

    def violations(self) -> list:
        return self._violations.copy()

# Embedded test suite
def _test_helix_law():
    law = HelixLaw()
    law.enact("no_write", lambda ctx: ctx.get("mode") != "write")
    assert law.evaluate({"mode": "read"}) is True
    assert law.evaluate({"mode": "write"}) is False
    assert "no_write" in law.violations()
    law.revoke("no_write")
    assert law.evaluate({"mode": "write"}) is True
    print("HelixLaw tests: PASSED")

if __name__ == "__main__":
    _test_helix_law()
