"""
Helix Governance Module: helix_registry

Maintains identity tokens, signature lineage, and registration tracking.
Ensures each component and action can be traced to an origin and authority.
"""

class HelixRegistry:
    def __init__(self):
        self._identities = {}
        self._signatures = {}
        self._lineage = {}

    def register(self, name: str, signature: str, parent: str = ""):
        if name in self._identities:
            raise ValueError(f"{name} already registered.")
        self._identities[name] = signature
        self._signatures[signature] = name
        if parent:
            self._lineage[name] = parent

    def resolve(self, signature: str) -> str:
        return self._signatures.get(signature, "")

    def verify(self, name: str, signature: str) -> bool:
        return self._identities.get(name) == signature

    def lineage_of(self, name: str) -> str:
        return self._lineage.get(name, "")

# Embedded test suite
def _test_helix_registry():
    r = HelixRegistry()
    r.register("scanner", "sig123")
    assert r.verify("scanner", "sig123") is True
    assert r.resolve("sig123") == "scanner"
    r.register("patcher", "sig456", parent="scanner")
    assert r.lineage_of("patcher") == "scanner"
    try:
        r.register("scanner", "sig999")
    except ValueError as e:
        assert "already registered" in str(e)
    print("HelixRegistry tests: PASSED")

if __name__ == "__main__":
    _test_helix_registry()
