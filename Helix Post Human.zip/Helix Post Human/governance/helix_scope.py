"""
Helix Governance Module: helix_scope

Defines scope boundaries for modules, operations, and call permissions.
Protects against unauthorized function access or state modification.
"""

class HelixScope:
    def __init__(self):
        self._scopes = {}
        self._permissions = {}

    def define_scope(self, name: str, allowed: list):
        self._scopes[name] = set(allowed)

    def grant(self, caller: str, callee: str):
        if caller not in self._permissions:
            self._permissions[caller] = set()
        self._permissions[caller].add(callee)

    def allowed(self, caller: str, callee: str) -> bool:
        scope_check = callee in self._scopes.get(caller, set())
        perm_check = callee in self._permissions.get(caller, set())
        return scope_check or perm_check

    def scope_of(self, name: str) -> set:
        return self._scopes.get(name, set())

# Fixed test suite
def _test_helix_scope():
    s = HelixScope()
    s.define_scope("audit", ["trace", "scan"])
    s.grant("audit", "patch")
    assert s.allowed("audit", "trace")
    assert s.allowed("audit", "patch")
    assert not s.allowed("audit", "compile")
    print("HelixScope tests: PASSED")

if __name__ == "__main__":
    _test_helix_scope()
