"""
Helix Tools Module: helix_compile

Bundles Helix-compatible modules and functions into a callable registry.
Used to compile execution paths, reduce overhead, and prepare runtime environments.
"""

class HelixCompile:
    def __init__(self):
        self._registry = {}

    def register(self, name: str, fn):
        if not callable(fn):
            raise TypeError("Only callables can be registered.")
        self._registry[name] = fn

    def compile(self) -> dict:
        return dict(self._registry)

    def get(self, name: str):
        return self._registry.get(name)

    def list(self) -> list:
        return sorted(self._registry.keys())

# Embedded test suite
def _test_helix_compile():
    c = HelixCompile()
    c.register("add", lambda x, y: x + y)
    c.register("sub", lambda x, y: x - y)
    assert c.get("add")(3, 2) == 5
    assert "sub" in c.list()
    compiled = c.compile()
    assert compiled["add"](4, 1) == 5
    print("HelixCompile tests: PASSED")

if __name__ == "__main__":
    _test_helix_compile()
