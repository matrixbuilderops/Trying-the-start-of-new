"""
Helix Tools Module: helix_flux

Handles directional flow of data through conditional and sequential pipelines.
Used for routing output between Helix modules.
"""

class HelixFlux:
    def __init__(self):
        self._routes = {}

    def route(self, origin: str, dest: str, transform=None):
        self._routes[origin] = (dest, transform or (lambda x: x))

    def transfer(self, origin: str, value):
        if origin not in self._routes:
            raise KeyError(f"No route from '{origin}'")
        dest, transform = self._routes[origin]
        return dest, transform(value)

# Embedded test
def _test_helix_flux():
    fx = HelixFlux()
    fx.route("scanner", "patcher", lambda x: x + 1)
    target, out = fx.transfer("scanner", 4)
    assert target == "patcher"
    assert out == 5
    print("HelixFlux tests: PASSED")

if __name__ == "__main__":
    _test_helix_flux()
