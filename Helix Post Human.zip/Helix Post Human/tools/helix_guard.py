"""
Helix Core Module: helix_guard

Enforces execution integrity and protects against:
- Invalid state transitions
- Unauthorized command calls
- Structural mutations

Operates as an execution firewall.
"""

class HelixGuard:
    def __init__(self):
        self._frozen = False
        self._blacklist = set()
        self._log = []

    def freeze(self):
        self._frozen = True
        self._log.append("System frozen")

    def unfreeze(self):
        self._frozen = False
        self._log.append("System unfrozen")

    def is_frozen(self) -> bool:
        return self._frozen

    def blacklist(self, cmd: str):
        self._blacklist.add(cmd)
        self._log.append(f"Blacklisted: {cmd}")

    def validate(self, cmd: str) -> bool:
        if self._frozen:
            self._log.append(f"Blocked {cmd}: system frozen")
            return False
        if cmd in self._blacklist:
            self._log.append(f"Blocked {cmd}: blacklisted")
            return False
        self._log.append(f"Allowed: {cmd}")
        return True

    def get_log(self) -> list:
        return self._log.copy()

# Embedded test suite
def _test_helix_guard():
    guard = HelixGuard()
    assert guard.validate("deploy") == True
    guard.freeze()
    assert guard.validate("deploy") == False
    guard.unfreeze()
    guard.blacklist("reboot")
    assert guard.validate("reboot") == False
    assert "Blacklisted: reboot" in guard.get_log()
    print("HelixGuard tests: PASSED")

if __name__ == "__main__":
    _test_helix_guard()
