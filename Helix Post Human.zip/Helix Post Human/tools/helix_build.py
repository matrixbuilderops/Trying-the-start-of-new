"""
Helix Tools Module: helix_build

Consolidates compiled Helix functions into a runtime dispatch table.
Final step before ecosystem execution.

This is the last module in the Tools layer.
"""

class HelixBuild:
    def __init__(self):
        self._dispatch = {}

    def bind(self, registry: dict):
        if not isinstance(registry, dict):
            raise TypeError("Expected dictionary input for registry")
        self._dispatch.update(registry)

    def execute(self, name: str, *args, **kwargs):
        if name not in self._dispatch:
            raise KeyError(f"Function {name} not registered.")
        return self._dispatch[name](*args, **kwargs)

    def list(self) -> list:
        return sorted(self._dispatch.keys())

# Embedded test suite
def _test_helix_build():
    b = HelixBuild()
    b.bind({"sum": lambda x, y: x + y})
    assert b.execute("sum", 2, 3) == 5
    try:
        b.execute("nonexistent")
    except KeyError as e:
        assert "not registered" in str(e)
    print("HelixBuild tests: PASSED")

if __name__ == "__main__":
    _test_helix_build()
