"""
Helix Tools Module: helix_scan

Scans Python code for structural issues, docstring completeness,
function definitions, and import patterns.

No execution is performed — pure static pass.
"""

import re

class HelixScan:
    def __init__(self):
        self._report = []

    def scan(self, code: str) -> list:
        self._report.clear()
        lines = code.splitlines()

        for idx, line in enumerate(lines, 1):
            if "import " in line and not line.strip().startswith("#"):
                if " as " not in line and "," in line:
                    self._report.append(f"Line {idx}: Consider one import per line")

            if len(line) > 88:
                self._report.append(f"Line {idx}: Line too long")

            if re.match(r"^def .+\):", line) and '"""' not in lines[idx:idx+3]:
                self._report.append(f"Line {idx}: Missing docstring")

        return self._report.copy()

# Embedded test suite
def _test_helix_scan():
    sample = "import os, sys\ndef foo():\n    return 1\n" + "a = 1" * 40
    scanner = HelixScan()
    result = scanner.scan(sample)
    assert any("Line 1:" in x for x in result)
    assert any("Line 2:" in x for x in result)
    print("HelixScan tests: PASSED")

if __name__ == "__main__":
    _test_helix_scan()
