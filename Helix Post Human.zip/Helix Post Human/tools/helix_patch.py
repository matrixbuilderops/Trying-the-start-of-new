"""
Helix Tools Module: helix_patch

Injects deterministic, constrained patches into file logic.
Used for structural rewrites, docstring additions, and type enforcement.

No mutation outside defined safe bounds.
"""

class HelixPatch:
    def __init__(self):
        self._history = []

    def patch(self, content: str, target: str, replacement: str) -> str:
        if target not in content:
            raise ValueError("Target not found in content.")
        result = content.replace(target, replacement)
        self._history.append((target, replacement))
        return result

    def last_patch(self) -> tuple:
        return self._history[-1] if self._history else ("", "")

    def get_history(self) -> list:
        return self._history.copy()

# Embedded test suite
def _test_helix_patch():
    patcher = HelixPatch()
    original = "def foo():\n    return 42"
    modified = patcher.patch(original, "return 42", "return 43")
    assert "return 43" in modified
    assert patcher.last_patch() == ("return 42", "return 43")
    try:
        patcher.patch(original, "nonexistent", "return 0")
    except ValueError as e:
        assert str(e) == "Target not found in content."
    print("HelixPatch tests: PASSED")

if __name__ == "__main__":
    _test_helix_patch()
