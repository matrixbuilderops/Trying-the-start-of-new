"""
Helix Tools Module: helix_fuse

Fuses validated logic chains or modules into composite callable units.
Used for dynamic reconfiguration of patched logic.
"""

class HelixFuse:
    def __init__(self):
        self._fused = {}

    def fuse(self, name: str, funcs: list):
        def composed(*args, **kwargs):
            result = args
            for f in funcs:
                if isinstance(result, tuple):
                    result = f(*result, **kwargs)
                else:
                    result = f(result, **kwargs)
            return result
        self._fused[name] = composed

    def run(self, name: str, *args, **kwargs):
        if name not in self._fused:
            raise ValueError(f"No fused chain for '{name}'")
        return self._fused[name](*args, **kwargs)

# Embedded test
def _test_helix_fuse():
    f = HelixFuse()
    f.fuse("adder", [lambda x, y: x + y, lambda z: z * 2])
    assert f.run("adder", 3, 4) == 14  # (3+4) * 2
    print("HelixFuse tests: PASSED")

if __name__ == "__main__":
    _test_helix_fuse()
