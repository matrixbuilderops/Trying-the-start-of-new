"""
Helix Tools Module: helix_policy

Handles enforcement of system-wide policy directives such as:
- Freeze state
- Policy rules
- Trust registry

Used to control top-level behavioral constraints and enforce governance.
"""

class HelixPolicy:
    def __init__(self):
        self._frozen = False
        self._rules = {}
        self._trust = {}

    def freeze(self):
        self._frozen = True

    def unfreeze(self):
        self._frozen = False

    def is_frozen(self) -> bool:
        return self._frozen

    def set_rule(self, key: str, value: str):
        if self._frozen:
            raise RuntimeError("System is frozen — cannot modify policy")
        self._rules[key] = value

    def get_rule(self, key: str) -> str:
        return self._rules.get(key, "")

    def register_trust(self, name: str, level: int):
        self._trust[name] = level

    def trust_level(self, name: str) -> int:
        return self._trust.get(name, 0)

# Embedded test suite
def _test_helix_policy():
    p = HelixPolicy()
    p.set_rule("runtime_mode", "safe")
    assert p.get_rule("runtime_mode") == "safe"
    p.register_trust("compiler", 5)
    assert p.trust_level("compiler") == 5
    p.freeze()
    try:
        p.set_rule("runtime_mode", "fast")
    except RuntimeError as e:
        assert str(e) == "System is frozen — cannot modify policy"
    p.unfreeze()
    assert not p.is_frozen()
    print("HelixPolicy tests: PASSED")

if __name__ == "__main__":
    _test_helix_policy()
