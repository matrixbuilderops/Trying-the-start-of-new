"""
Helix Tools Module: helix_introspect

Exposes callable structure, signatures, and docstrings of modules.
Used for visibility, diagnostics, and recursive tool understanding.
"""

import types

class HelixIntrospect:
    def scan(self, obj) -> dict:
        if not isinstance(obj, types.ModuleType) and not hasattr(obj, "__dict__"):
            raise TypeError("Invalid introspection target")

        result = {}
        for name in dir(obj):
            attr = getattr(obj, name)
            if callable(attr):
                doc = attr.__doc__ or ""
                result[name] = doc.strip()
        return result

# Embedded test suite
def _test_helix_introspect():
    class Dummy:
        def alpha(self): "Alpha method." ; pass
        def beta(self): pass

    scanner = HelixIntrospect()
    out = scanner.scan(Dummy)
    assert "alpha" in out
    assert "Alpha method." in out["alpha"]
    assert "beta" in out
    print("HelixIntrospect tests: PASSED")

if __name__ == "__main__":
    _test_helix_introspect()
