"""
Helix Utility Module: helix_chain

Defines and executes ordered sequences of function calls.
Used for linear validation chains, patch workflows, and runtime pipelines.
"""

class HelixChain:
    def __init__(self):
        self._chain = []

    def add(self, func):
        if not callable(func):
            raise TypeError("Only callables may be chained.")
        self._chain.append(func)

    def run(self, initial):
        result = initial
        for func in self._chain:
            result = func(result)
        return result

    def clear(self):
        self._chain.clear()

# Embedded test suite
def _test_helix_chain():
    c = HelixChain()
    c.add(lambda x: x + 1)
    c.add(lambda x: x * 2)
    assert c.run(3) == 8  # ((3 + 1) * 2)
    c.clear()
    assert c.run(5) == 5  # empty chain returns input
    print("HelixChain tests: PASSED")

if __name__ == "__main__":
    _test_helix_chain()
