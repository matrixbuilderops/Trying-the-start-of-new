"""
Helix Utility Module: helix_report

Aggregates, formats, and outputs validation results and runtime decisions.
Used to present Helix decisions clearly and consistently.
"""

class HelixReport:
    def __init__(self):
        self._log = []

    def record(self, msg: str):
        self._log.append(msg)

    def dump(self) -> str:
        return "\n".join(self._log)

    def clear(self):
        self._log.clear()

    def count(self) -> int:
        return len(self._log)

# Embedded test suite
def _test_helix_report():
    r = HelixReport()
    r.record("Scan complete.")
    r.record("All clear.")
    assert "Scan complete." in r.dump()
    assert r.count() == 2
    r.clear()
    assert r.count() == 0
    print("HelixReport tests: PASSED")

if __name__ == "__main__":
    _test_helix_report()
