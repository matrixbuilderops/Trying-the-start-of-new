"""
Helix Utility Module: helix_runner

Entry orchestrator. Launches Helix runtime pipeline with validated components.
Controls boot sequence, integration, and execution context preparation.
"""

class HelixRunner:
    def __init__(self, compiler, builder, policy, registry, scope, law, seal, warden):
        self.compiler = compiler
        self.builder = builder
        self.policy = policy
        self.registry = registry
        self.scope = scope
        self.law = law
        self.seal = seal
        self.warden = warden

    def boot(self):
        compiled = self.compiler.compile()
        self.builder.bind(compiled)

    def invoke(self, func_name: str, context: dict, content: str, seal_name: str, caller: str, callee: str, *args, **kwargs):
        if not self.warden.authorize(caller, callee, context, content, seal_name):
            raise PermissionError("Execution blocked by Helix governance")
        return self.builder.execute(func_name, *args, **kwargs)

# Fixed test with mock warden implementation
def _test_helix_runner():
    class DummyCompiler:
        def compile(self): return {"sum": lambda x, y: x + y}

    class DummyBuilder:
        def bind(self, reg): self._reg = reg
        def execute(self, name, *args): return self._reg[name](*args)

    class DummyWarden:
        def authorize(self, caller, callee, context, content, seal_name):
            return "unsafe" not in content and context.get("mode") == "safe"

    class PassThrough:
        pass

    r = HelixRunner(
        DummyCompiler(),
        DummyBuilder(),
        PassThrough(),
        PassThrough(),
        PassThrough(),
        PassThrough(),
        PassThrough(),
        DummyWarden()
    )
    r.boot()
    result = r.invoke("sum", {"mode": "safe"}, "return safe", "sum", "core", "tools", 3, 2)
    assert result == 5
    print("HelixRunner tests: PASSED")

if __name__ == "__main__":
    _test_helix_runner()
