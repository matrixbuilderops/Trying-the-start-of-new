"""
Helix Utility Module: helix_traceback

Captures and formats exception tracebacks for Helix runtime operations.
Used for consistent error visibility, logging, and debugging.
"""

import traceback

class HelixTraceback:
    def __init__(self):
        self._last = ""

    def capture(self, ex: Exception):
        self._last = "".join(traceback.format_exception(type(ex), ex, ex.__traceback__))

    def last(self) -> str:
        return self._last

    def clear(self):
        self._last = ""

# Embedded test suite
def _test_helix_traceback():
    t = HelixTraceback()
    try:
        1 / 0
    except Exception as e:
        t.capture(e)
    assert "ZeroDivisionError" in t.last()
    t.clear()
    assert t.last() == ""
    print("HelixTraceback tests: PASSED")

if __name__ == "__main__":
    _test_helix_traceback()
