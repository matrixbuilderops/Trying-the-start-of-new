"""
Helix Utility Module: helix_loader

Initializes all Helix modules into memory.
Creates registry-ready references and prepares execution environment.
"""

class HelixLoader:
    def __init__(self):
        self._modules = {}

    def load(self, name: str, module: object):
        self._modules[name] = module

    def get(self, name: str):
        return self._modules.get(name)

    def all(self) -> dict:
        return dict(self._modules)

# Embedded test suite
def _test_helix_loader():
    l = HelixLoader()
    class Dummy: pass
    mod = Dummy()
    l.load("dummy", mod)
    assert l.get("dummy") is mod
    assert isinstance(l.all(), dict)
    assert "dummy" in l.all()
    print("HelixLoader tests: PASSED")

if __name__ == "__main__":
    _test_helix_loader()
