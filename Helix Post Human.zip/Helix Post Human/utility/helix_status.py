"""
Helix Utility Module: helix_status

Monitors and exposes Helix operational status.
Tracks boot, validation, and execution phases with state flags.
"""

class HelixStatus:
    def __init__(self):
        self._state = {
            "booted": False,
            "validated": False,
            "executing": False,
        }

    def set(self, phase: str, value: bool):
        if phase not in self._state:
            raise KeyError("Unknown status phase")
        self._state[phase] = value

    def get(self, phase: str) -> bool:
        return self._state.get(phase, False)

    def all(self) -> dict:
        return dict(self._state)

# Embedded test suite
def _test_helix_status():
    s = HelixStatus()
    s.set("booted", True)
    s.set("validated", True)
    assert s.get("booted") is True
    assert s.get("executing") is False
    assert isinstance(s.all(), dict)
    print("HelixStatus tests: PASSED")

if __name__ == "__main__":
    _test_helix_status()
