"""
Helix Core Module: helix_runtime

Central execution kernel for Helix ecosystem.

Routes:
- Module calls
- Input validation
- Result standardization

Features:
- Function registry
- Type enforcement (via helix_types)
- Error fallback (via helix_error)
- Zero import
"""

# Internal replica of HelixTypes
class _Types:
    @staticmethod
    def typename(obj) -> str:
        return str(type(obj)).split("'")[1]

# Internal replica of HelixError
class HelixError:
    def __init__(self, code: str, message: str, context: str = ""):
        self.code = code
        self.message = message
        self.context = context

    def as_dict(self) -> dict:
        return {
            "code": self.code,
            "message": self.message,
            "context": self.context
        }

    def __str__(self) -> str:
        return f"[ERROR {self.code}] {self.message} (Context: {self.context})"

class HelixRuntime:
    def __init__(self):
        self._registry = {}

    def register(self, name: str, func, param_type: str):
        self._registry[name] = {"func": func, "type": param_type}

    def call(self, name: str, arg):
        if name not in self._registry:
            return HelixError("E404", "Function not found", name)
        func_info = self._registry[name]
        expected_type = func_info["type"]
        if _Types.typename(arg) != expected_type:
            return HelixError("E400", "Invalid argument type", f"Expected {expected_type}, got {_Types.typename(arg)}")
        try:
            return func_info["func"](arg)
        except Exception as e:
            return HelixError("E500", "Runtime failure", str(e))

# Embedded test suite
def _test_helix_runtime():
    def triple(x: int) -> int:
        return x * 3

    rt = HelixRuntime()
    rt.register("triple", triple, "int")

    assert rt.call("triple", 4) == 12
    err = rt.call("triple", "4")
    assert isinstance(err, HelixError) and err.code == "E400"
    nf = rt.call("unknown", 1)
    assert isinstance(nf, HelixError) and nf.code == "E404"
    print("HelixRuntime tests: PASSED")

if __name__ == "__main__":
    _test_helix_runtime()
