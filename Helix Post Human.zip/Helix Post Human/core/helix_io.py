"""
Helix Core Module: helix_io

A zero-import, deterministic file system interface for Helix tools.

Features:
- Read text file
- Write text file
- Check file existence (simulated)
- Directory listing (static simulation for now)

This is a foundational IO abstraction to avoid standard library dependencies.
"""

class HelixIO:
    def __init__(self):
        self._fs = {}  # internal simulation for safe read/write

    def write(self, path: str, content: str) -> bool:
        norm_path = self._normalize(path)
        self._fs[norm_path] = content
        return True

    def read(self, path: str) -> str:
        norm_path = self._normalize(path)
        if norm_path in self._fs:
            return self._fs[norm_path]
        return f"[ERROR] File '{norm_path}' not found."

    def exists(self, path: str) -> bool:
        return self._normalize(path) in self._fs

    def listdir(self, path: str) -> list:
        base = self._normalize(path)
        prefix = base.rstrip("/") + "/"
        seen = set()
        for file in self._fs:
            if file.startswith(prefix):
                rel = file[len(prefix):].split("/")[0]
                seen.add(rel)
        return list(seen)

    def _normalize(self, path: str) -> str:
        return "/" + "/".join([p for p in path.strip().split("/") if p not in ("", ".")])

# Embedded test suite
def _test_helix_io():
    hio = HelixIO()
    assert hio.write("/a/b.txt", "hello") is True
    assert hio.read("/a/b.txt") == "hello"
    assert hio.exists("/a/b.txt") is True
    assert hio.exists("/a/c.txt") is False
    assert "b.txt" in hio.listdir("/a")
    assert hio.read("/a/missing.txt").startswith("[ERROR]")
    print("HelixIO tests: PASSED")

if __name__ == "__main__":
    _test_helix_io()
