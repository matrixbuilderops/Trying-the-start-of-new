"""
Helix Core Module: helix_doc

Enforces docstring presence, minimum completeness, and structure in functions.

Checks:
- Docstring exists
- Summary present
- Param + return structure
- Self-contained, zero-import

Does NOT parse full AST — works on line strings alone.
"""

class HelixDoc:
    def __init__(self, lines: list[str]):
        self.lines = lines
        self.issues = []

    def run(self) -> list[str]:
        in_func = False
        doc_lines = []
        collecting = False

        for idx, line in enumerate(self.lines):
            stripped = line.strip()
            if stripped.startswith("def "):
                in_func = True
                collecting = False
                doc_lines = []
            elif in_func and '"""' in stripped:
                if not collecting:
                    collecting = True
                    doc_lines = [stripped.strip('"""')]
                else:
                    doc_lines.append(stripped.strip('"""'))
                    self._validate_doc(idx + 1 - len(doc_lines), doc_lines)
                    in_func = False
                    collecting = False
            elif collecting:
                doc_lines.append(stripped)

        return self.issues

    def _validate_doc(self, start_line: int, doc: list[str]):
        if not doc or not doc[0].strip():
            self.issues.append(f"Line {start_line}: docstring missing summary")
        if not any("param" in l.lower() for l in doc):
            self.issues.append(f"Line {start_line}: docstring missing parameter description")
        if not any("return" in l.lower() for l in doc):
            self.issues.append(f"Line {start_line}: docstring missing return description")

# Embedded test suite
def _test_helix_doc():
    sample_code = [
        "def foo(x):\n",
        '    """\n',
        "    Increment a value\n",
        "    param x: integer\n",
        "    return: incremented integer\n",
        '    """\n',
        "    return x + 1\n",
        "\n",
        "def bar(y):\n",
        '    """\n',
        "    param y: number\n",
        '    """\n',
        "    return y * y\n"
    ]
    doc_checker = HelixDoc(sample_code)
    results = doc_checker.run()
    assert any("missing return" in x for x in results)
    assert any("missing summary" in x for x in results)
    print("HelixDoc tests: PASSED")

if __name__ == "__main__":
    _test_helix_doc()
