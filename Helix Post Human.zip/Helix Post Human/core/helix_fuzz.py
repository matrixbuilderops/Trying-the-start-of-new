"""
Helix Core Module: helix_fuzz

A zero-import function fuzzing engine for Helix.

Features:
- Generates edge-case inputs based on declared types
- Calls target functions with mutations
- Returns result map + error trace

No external modules. Fully deterministic.
"""

class HelixFuzz:
    def __init__(self, target_func):
        self.func = target_func
        self.trials = []

    def generate_inputs(self, type_hint: str) -> list:
        if type_hint == "int":
            return [0, 1, -1, 2**31, -2**31]
        elif type_hint == "str":
            return ["", "a", " "*1000, "\n", "\0", "🔥"]
        elif type_hint == "bool":
            return [True, False]
        elif type_hint == "list":
            return [[], [1], ["a", "b"], [None]*10]
        elif type_hint == "dict":
            return [{}, {"key": "value"}, {1: None}]
        return [None]

    def run(self, param_type: str) -> list[dict]:
        results = []
        for val in self.generate_inputs(param_type):
            try:
                output = self.func(val)
                results.append({"input": val, "output": output, "error": None})
            except Exception as e:
                results.append({"input": val, "output": None, "error": str(e)})
        return results

# Embedded test suite
def _test_helix_fuzz():
    def square(x: int) -> int:
        return x * x

    fuzz = HelixFuzz(square)
    result = fuzz.run("int")
    assert any(isinstance(r["output"], int) for r in result)
    assert all("error" in r for r in result)
    print("HelixFuzz tests: PASSED")

if __name__ == "__main__":
    _test_helix_fuzz()
