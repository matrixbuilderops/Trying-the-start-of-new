"""
Helix Core Module: helix_types

A zero-import, self-contained type enforcement and validation module.
Replaces `typing` and runtime checks with Helix-compliant logic.

Supports:
- Type conformance
- Homogeneous container checks
- Type name resolution
- Embedded test suite

No stdlib, no runtime imports — logic pure.
"""

class HelixTypes:
    @staticmethod
    def typename(obj) -> str:
        return str(type(obj)).split("'")[1]

    @staticmethod
    def is_type(obj, type_name: str) -> bool:
        return HelixTypes.typename(obj) == type_name

    @staticmethod
    def is_list_of(obj, subtype: str) -> bool:
        if HelixTypes.typename(obj) != "list":
            return False
        for item in obj:
            if HelixTypes.typename(item) != subtype:
                return False
        return True

    @staticmethod
    def is_dict_of(obj, key_type: str, val_type: str) -> bool:
        if HelixTypes.typename(obj) != "dict":
            return False
        for k, v in obj.items():
            if HelixTypes.typename(k) != key_type or HelixTypes.typename(v) != val_type:
                return False
        return True

    @staticmethod
    def is_strictly(obj, signature: str) -> bool:
        """
        signature: "list[int]", "dict[str,int]", "str", etc.
        """
        if signature.startswith("list[") and signature.endswith("]"):
            subtype = signature[5:-1]
            return HelixTypes.is_list_of(obj, subtype)
        if signature.startswith("dict[") and signature.endswith("]"):
            pair = signature[5:-1].split(",")
            if len(pair) != 2:
                return False
            key_type, val_type = pair
            return HelixTypes.is_dict_of(obj, key_type, val_type)
        return HelixTypes.is_type(obj, signature)

# Embedded test suite
def _test_helix_types():
    assert HelixTypes.typename("abc") == "str"
    assert HelixTypes.is_type(123, "int")
    assert HelixTypes.is_type([], "list")
    assert HelixTypes.is_list_of(["a", "b"], "str")
    assert not HelixTypes.is_list_of([1, "b"], "str")
    assert HelixTypes.is_dict_of({"a": 1, "b": 2}, "str", "int")
    assert not HelixTypes.is_dict_of({1: "a"}, "str", "int")
    assert HelixTypes.is_strictly(["x", "y"], "list[str]")
    assert HelixTypes.is_strictly({"x": 1}, "dict[str,int]")
    assert not HelixTypes.is_strictly({"x": 1}, "dict[int,str]")
    print("HelixTypes tests: PASSED")

if __name__ == "__main__":
    _test_helix_types()
