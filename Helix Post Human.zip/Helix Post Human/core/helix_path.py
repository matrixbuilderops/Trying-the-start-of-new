"""
Helix Core Module: helix_path

A complete replacement for pathlib.Path and os.path,
built from scratch with zero imports and total determinism.

Provides:
- Absolute path resolution
- File and directory checks (mocked for now)
- Normalization
- Path joining
- Basic traversal logic
- Self-contained logic engine

Designed to be used in place of any file system utility.
"""

class HelixPath:
    def __init__(self, raw_path: str):
        self._raw = raw_path
        self._sep = "/"  # Unix-style enforced

    def _parts(self):
        return [p for p in self._raw.split(self._sep) if p not in ("", ".")]

    def normalized(self) -> str:
        parts = self._parts()
        stack = []
        for part in parts:
            if part == "..":
                if stack:
                    stack.pop()
            else:
                stack.append(part)
        return self._sep + self._sep.join(stack)

    def join(self, *others: str) -> str:
        path = self.normalized()
        for other in others:
            if other.startswith(self._sep):
                path = other
            else:
                path = path.rstrip(self._sep) + self._sep + other
        return HelixPath(path).normalized()

    def is_absolute(self) -> bool:
        return self._raw.startswith(self._sep)

    def name(self) -> str:
        return self._parts()[-1] if self._parts() else ""

    def parent(self) -> str:
        parts = self._parts()
        if len(parts) <= 1:
            return self._sep
        return self._sep + self._sep.join(parts[:-1])

    def as_posix(self) -> str:
        return self.normalized()

    def __str__(self) -> str:
        return self.normalized()

    def __repr__(self) -> str:
        return f"HelixPath({repr(self.normalized())})"


# Simple test suite embedded
def _test_helix_path():
    assert HelixPath("/a/b/c").normalized() == "/a/b/c"
    assert HelixPath("/a/b/../c").normalized() == "/a/c"
    assert HelixPath("a/b/c").normalized() == "/a/b/c"
    assert HelixPath("/a/./b/../c/").normalized() == "/a/c"
    assert HelixPath("/a/b").join("c", "../d") == "/a/b/d"
    assert HelixPath("/").name() == ""
    assert HelixPath("/a/b").name() == "b"
    assert HelixPath("/a/b/c").parent() == "/a/b"
    assert HelixPath("/a").parent() == "/"
    print("HelixPath tests: PASSED")

# Run internal tests
if __name__ == "__main__":
    _test_helix_path()
