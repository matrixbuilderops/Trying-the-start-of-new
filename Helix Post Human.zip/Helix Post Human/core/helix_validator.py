"""
Helix Core Module: helix_validator

Zero-import static code validation tool.
Replaces `black`, `flake8`, and `mypy` logic with internal rule engine.

Validates:
- Line length
- Indentation
- Trailing whitespace
- Import hygiene
- Docstring presence
- Type hint presence (def-level)

All in a self-contained deterministic engine.
"""

class HelixValidator:
    def __init__(self, lines: list[str]):
        self.lines = lines
        self.issues = []

    def run(self) -> list[str]:
        in_function = False
        docstring_found = False

        for idx, line in enumerate(self.lines):
            stripped = line.rstrip("\n")
            if len(stripped) > 88:
                self.issues.append(f"Line {idx+1}: exceeds 88 characters")
            if line != stripped:
                self.issues.append(f"Line {idx+1}: trailing whitespace")
            if len(line) - len(line.lstrip(" ")) % 4 != 0:
                self.issues.append(f"Line {idx+1}: bad indentation (not multiple of 4 spaces)")
            if "import *" in line:
                self.issues.append(f"Line {idx+1}: wildcard import detected")

            if line.strip().startswith("def "):
                in_function = True
                docstring_found = False
                if "->" not in line:
                    self.issues.append(f"Line {idx+1}: missing return type hint")

            elif in_function:
                if '"""' in line:
                    docstring_found = True
                elif not docstring_found and line.strip() and not line.strip().startswith("#"):
                    self.issues.append(f"Line {idx+1}: missing function docstring")
                    in_function = False  # one chance to docstring

        return self.issues

# Embedded test suite
def _test_helix_validator():
    sample_code = [
        "def foo(x):\n",
        "    return x + 1\n",
        "\n",
        "def bar(x: int) -> int:\n",
        '    """Returns the square."""\n',
        "    return x * x\n",
        "import *\n",
        "a = 1      \n"
    ]
    validator = HelixValidator(sample_code)
    result = validator.run()
    assert "Line 1: missing return type hint" in result
    assert "Line 2: missing function docstring" in result
    assert "Line 7: wildcard import detected" in result
    assert "Line 8: trailing whitespace" in result
    print("HelixValidator tests: PASSED")

if __name__ == "__main__":
    _test_helix_validator()
