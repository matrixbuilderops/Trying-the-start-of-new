"""
Helix Core Module: helix_error

Zero-import deterministic error handling module for Helix systems.
Defines structured, immutable error objects for traceable logic fault states.

Does NOT raise exceptions. Errors are returned as structured state responses.
"""

class HelixError:
    def __init__(self, code: str, message: str, context: str = ""):
        self.code = code
        self.message = message
        self.context = context

    def __str__(self) -> str:
        parts = [f"[ERROR {self.code}] {self.message}"]
        if self.context:
            parts.append(f"(Context: {self.context})")
        return " ".join(parts)

    def as_dict(self) -> dict:
        return {
            "code": self.code,
            "message": self.message,
            "context": self.context
        }

    def __eq__(self, other) -> bool:
        return isinstance(other, HelixError) and self.as_dict() == other.as_dict()

# Embedded test suite
def _test_helix_error():
    err1 = HelixError("E001", "Invalid configuration")
    err2 = HelixError("E002", "Missing file", "helix_io.py")
    assert str(err1) == "[ERROR E001] Invalid configuration"
    assert "helix_io.py" in str(err2)
    assert err1.as_dict()["code"] == "E001"
    assert err1 != err2
    err3 = HelixError("E001", "Invalid configuration")
    assert err1 == err3
    print("HelixError tests: PASSED")

if __name__ == "__main__":
    _test_helix_error()
