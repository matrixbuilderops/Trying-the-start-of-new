import os

DEFAULT_COMMANDS = {
    "helix-help": [
        "You may type: diagnose, list-hooks, reroute, helix-help, fix-segment, verify-imports, verify-test-scripts, exit"
    ]
}

PHRASE_ALIASES = {
    "check everything": "diagnose",
    "help me": "helix-help",
    "repair segments": "fix-segment",
    "reroute system": "reroute"
}

class MindGate:
    def __init__(self, model_path):
        self.model_path = model_path
        self.commands = DEFAULT_COMMANDS
        self.load_qtl_model()

    def load_qtl_model(self):
        if os.path.exists(self.model_path):
            with open(self.model_path, 'r') as f:
                lines = f.readlines()
            current_command = None
            for line in lines:
                stripped = line.strip()
                if stripped.startswith("command:"):
                    current_command = stripped.split("command:")[1].strip()
                    self.commands[current_command] = []
                elif current_command:
                    self.commands[current_command].append(stripped)

    def list_commands(self):
        print("Available Commands:")
        for cmd in list(self.commands.keys()) + ["diagnose"]:
            print(f" - {cmd}")

    def run_command(self, cmd):
        if cmd == "diagnose":
            self.diagnose_runtime()
        elif cmd in self.commands:
            print(f"[{cmd}]")
            for line in self.commands[cmd]:
                print(f"> {line}")
        else:
            print(f"Command '{cmd}' not recognized.")

    def match_phrase(self, phrase):
        phrase = phrase.lower().strip()
        if phrase in self.commands:
            return phrase
        if phrase in PHRASE_ALIASES:
            return PHRASE_ALIASES[phrase]
        return None

    def diagnose_runtime(self):
        print("🧠 Real Diagnostics Activated")
        errors = []

        print("> [1] Running ChainLink Verification...")
        chainlink_code = os.system("python3 ChainLinkEngine_FIXED.py")
        if chainlink_code != 0:
            errors.append("ChainLinkEngine_FAILED")

        print("> [2] Running Test Script Generator...")
        testgen_code = os.system("python3 TestScriptGenerator.py")
        if testgen_code != 0:
            errors.append("TestScriptGenerator_FAILED")

        if not errors:
            print("✅ System reports no runtime failures.")
        else:
            print("❌ Errors detected:")
            for err in errors:
                print(f" - {err}")

def talk_to_mindgate():
    print(">> Connecting to MindGate Runtime (Ascenda Engine Active)")
    gate = MindGate(MINDGATE_MODEL_PATH)
    gate.list_commands()
    while True:
        user_input = input("MindGate > ").strip()
        if user_input in {"exit", "quit"}:
            print(">> Disconnecting from MindGate.")
            break
        elif user_input == "help":
            gate.list_commands()
        else:
            resolved = gate.match_phrase(user_input)
            if resolved:
                gate.run_command(resolved)
            else:
                print("Unrecognized input. Try 'help' or type a known phrase.")

if __name__ == "__main__":
    MINDGATE_MODEL_PATH = "Tools/Helix/Applications/Models/MindGate/MindGate.qtl"
    talk_to_mindgate()
